package com.mec.batteryguardian2;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView batteryValue, ramValue, tempValue, currentValue, insight, shizukuState, usageState, savingValue, experimentValue, fullChargeValue, anomalyValue, actionLog;
    private Switch autoSwitch;
    private ShizukuBridge shizuku;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        NotificationUtil.ensureChannels(this);
        shizuku = ShizukuBridge.get(this);
        shizuku.setCallback(() -> runOnUiThread(this::refreshAll));
        shizuku.ensureBound();
        setContentView(buildUi());
        askNotificationPermission();
        seedProtectedDefaults();
        refreshAll();
        UpdateManager.checkInBackground(this, false);
    }

    @Override protected void onResume() {
        super.onResume();
        shizuku.ensureBound();
        refreshAll();
    }

    @Override protected void onDestroy() { worker.shutdownNow(); super.onDestroy(); }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(Color.rgb(246,248,252));
        LinearLayout root = col();
        root.setPadding(dp(18), dp(24), dp(18), dp(36));
        sv.addView(root);

        // Android 15/16/17 edge-to-edge can place the first line under the status bar.
        // Apply the real system-bar inset so the title stays fully visible on Galaxy devices.
        sv.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            root.setPadding(dp(18), top + dp(18), dp(18), bottom + dp(36));
            return insets;
        });

        TextView title = text("Battery Guardian 2", 28, true, Color.rgb(23,32,51));
        title.setIncludeFontPadding(true);
        title.setPadding(0, dp(6), 0, dp(2));
        root.addView(title);
        TextView sub = text("Galaxy S26 Ultra · 자동 분석 → 해결 → 재확인", 14, false, Color.rgb(107,114,128));
        sub.setPadding(0,dp(2),0,dp(12)); root.addView(sub);

        LinearLayout stats1 = row();
        batteryValue = statCard(stats1,"배터리","--");
        ramValue = statCard(stats1,"RAM","--");
        root.addView(stats1);
        LinearLayout stats2 = row();
        tempValue = statCard(stats2,"온도","--");
        currentValue = statCard(stats2,"현재 소모","--");
        root.addView(stats2);

        LinearLayout autoCard = card();
        LinearLayout autoRow = row();
        LinearLayout labels = col(); labels.setLayoutParams(new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        labels.addView(text("스마트 자동 관리",18,true,Color.rgb(23,32,51)));
        labels.addView(text("최근 사용하지 않은 앱만 골라 백그라운드 활동을 줄이고, 다시 쓰면 자동 복구합니다.",13,false,Color.rgb(107,114,128)));
        autoRow.addView(labels);
        autoSwitch = new Switch(this); autoSwitch.setChecked(AppPrefs.autoManage(this)); autoRow.addView(autoSwitch);
        autoCard.addView(autoRow);
        autoSwitch.setOnCheckedChangeListener((v,checked)->{
            AppPrefs.setAutoManage(this,checked);
            if (checked) {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) askNotificationPermission();
                try { MonitorService.start(this); } catch (Exception e) { toastDialog("자동 관리 시작 실패",e.getMessage()); }
            } else MonitorService.stop(this);
        });
        root.addView(autoCard);

        LinearLayout explainCard = card();
        explainCard.addView(text("지금 상태를 쉽게 설명하면",17,true,Color.rgb(23,32,51)));
        insight = text("확인 중...",15,false,Color.rgb(45,55,72)); insight.setPadding(0,dp(8),0,0); explainCard.addView(insight);
        savingValue = text("실제 절감 효과: 학습 중",14,true,Color.rgb(15,157,88)); savingValue.setPadding(0,dp(10),0,0); explainCard.addView(savingValue);
        experimentValue = text("실험 모드: 대기",13,false,Color.rgb(107,114,128)); experimentValue.setPadding(0,dp(5),0,0); explainCard.addView(experimentValue);
        fullChargeValue = text("완충 추적: 100% 충전 대기",13,false,Color.rgb(107,114,128)); fullChargeValue.setPadding(0,dp(5),0,0); explainCard.addView(fullChargeValue);
        anomalyValue = text("변화 감지: 정상 감시 중",13,false,Color.rgb(107,114,128)); anomalyValue.setPadding(0,dp(5),0,0); explainCard.addView(anomalyValue);
        root.addView(explainCard);

        Button optimize = primaryButton("⚡ 스마트 최적화 한 번에 실행");
        optimize.setOnClickListener(v -> runSmartOptimize()); root.addView(optimize);
        Button background = secondaryButton("🔒 백그라운드 제한 상세 실행");
        background.setOnClickListener(v -> runBackgroundRestrict()); root.addView(background);
        Button ram = secondaryButton("🚀 스마트 RAM 부스트");
        ram.setOnClickListener(v -> runRamBoost()); root.addView(ram);
        Button experiment = secondaryButton("🧪 자동 실험 모드 시작");
        experiment.setOnClickListener(v -> startExperiment()); root.addView(experiment);

        LinearLayout perm = card();
        perm.addView(text("필수 연결",17,true,Color.rgb(23,32,51)));
        usageState = text("사용 기록: 확인 중",14,false,Color.rgb(107,114,128)); perm.addView(usageState);
        shizukuState = text("Shizuku: 확인 중",14,false,Color.rgb(107,114,128)); perm.addView(shizukuState);
        Button usage = smallButton("사용 기록 권한 열기");
        usage.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
        perm.addView(usage);
        Button sh = smallButton("Shizuku 연결 / 권한");
        sh.setOnClickListener(v -> handleShizuku()); perm.addView(sh);
        root.addView(perm);

        LinearLayout logs = card();
        logs.addView(text("최근 자동 해결 / 변화 감지",17,true,Color.rgb(23,32,51)));
        actionLog = text("아직 기록이 없습니다.",13,false,Color.rgb(107,114,128)); actionLog.setPadding(0,dp(8),0,0); logs.addView(actionLog);
        root.addView(logs);

        LinearLayout bottom = row();
        Button protect = smallButton("보호 앱"); protect.setOnClickListener(v -> startActivity(new Intent(this, ProtectedAppsActivity.class))); bottom.addView(protect,new LinearLayout.LayoutParams(0,dp(46),1));
        Button settings = smallButton("설정 / 업데이트"); settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class))); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0,dp(46),1); bp.setMargins(dp(8),0,0,0); bottom.addView(settings,bp);
        root.addView(bottom);

        TextView version = text("Battery Guardian 2  ·  v2.0.7  ·  Rule Engine 1",12,false,Color.rgb(130,138,150));
        version.setGravity(Gravity.CENTER); version.setPadding(0,dp(22),0,0); root.addView(version);
        return sv;
    }

    private void refreshAll() {
        SystemSnapshot s = SystemSnapshot.capture(this);
        FullChargeTracker.observe(this, s);
        AnomalyDetector.observe(this, s);
        batteryValue.setText(s.batteryPercent < 0 ? "--" : s.batteryPercent + "%");
        ramValue.setText(s.ramUsedPercent + "%\n" + SystemSnapshot.gb(s.totalRam-s.availRam) + " / " + SystemSnapshot.gb(s.totalRam));
        tempValue.setText(String.format(java.util.Locale.KOREA,"%.1f℃",s.tempC));
        currentValue.setText(s.charging ? "충전 중" : (s.currentMa > 0 ? s.currentMa + " mA" : "측정 대기"));
        usageState.setText("사용 기록: " + (UsageAccess.granted(this)?"연결됨 ✓":"권한 필요"));
        String sz = !shizuku.binderAlive()?"Shizuku가 실행되지 않음":!shizuku.granted()?"권한 필요":shizuku.ready()?"연결됨 ✓ (UID "+shizuku.remoteUid()+")":"연결 중";
        shizukuState.setText("Shizuku: " + sz);
        float save = AppPrefs.confirmedSaving(this);
        savingValue.setText(save >= 0 ? String.format(java.util.Locale.KOREA,"실제 절감 효과: 최근 실험에서 약 %.1f%% 개선",save) : "실제 절감 효과: 아직 학습 중");
        experimentValue.setText("실험 모드: " + ExperimentController.status(this));
        fullChargeValue.setText(FullChargeTracker.status(this, s));
        String anomaly = AnomalyDetector.lastStatus(this);
        anomalyValue.setText(anomaly.startsWith("아직") ? "변화 감지: 정상 감시 중" : "변화 감지: " + anomaly);
        String last = AppPrefs.lastMessage(this);
        if (!last.isEmpty()) {
            if (last.contains("개의 뒤쪽 활동을 줄였습니다")) {
                int managed = PowerActions.managedCount(this);
                insight.setText("현재 백그라운드 제한 중인 앱 " + managed + "개의 설정을 유지하고 있습니다.\n같은 앱을 반복 제한하지 않고, 새 후보가 생길 때만 추가 적용합니다. 다시 사용한 앱은 자동 복구합니다.");
            } else insight.setText(last);
        }
        List<String> acts = new GuardianDb(this).recentActions(5);
        actionLog.setText(acts.isEmpty()?"아직 자동 해결 기록이 없습니다.":String.join("\n",acts));
    }

    private void runSmartOptimize() {
        if (!UsageAccess.granted(this)) { explainNeedUsage(); return; }
        if (!shizuku.granted()) { handleShizuku(); return; }
        shizuku.ensureBound();
        insight.setText("현재 상태를 확인하고, 중요한 앱은 제외한 뒤 실제로 줄일 수 있는 부분을 찾고 있습니다...");
        worker.submit(() -> {
            try { Thread.sleep(350); } catch (InterruptedException ignored) {}
            SmartEngine.Result preview = SmartEngine.analyze(this,false);
            SmartEngine.Result result = SmartEngine.analyze(this,true);
            String msg = result.explanation + "\n\n" + SmartEngine.predictedText(preview);
            AppPrefs.setLastMessage(this,msg);
            runOnUiThread(() -> { insight.setText(msg); refreshAll(); });
        });
    }


    private void runBackgroundRestrict() {
        if (!UsageAccess.granted(this)) { explainNeedUsage(); return; }
        if (!shizuku.granted()) { handleShizuku(); return; }
        shizuku.ensureBound();
        insight.setText("새롭게 오래 사용하지 않은 앱만 확인하고 있습니다. 이미 제한 중인 앱은 다시 건드리지 않습니다...");
        worker.submit(() -> {
            SmartEngine.Result result = SmartEngine.analyze(this,true);
            String msg = result.explanation;
            AppPrefs.setLastMessage(this,msg);
            runOnUiThread(() -> { insight.setText(msg); refreshAll(); });
        });
    }

    private void runRamBoost() {
        if (!UsageAccess.granted(this)) { explainNeedUsage(); return; }
        if (!shizuku.granted()) { handleShizuku(); return; }
        shizuku.ensureBound();
        SystemSnapshot before = SystemSnapshot.capture(this);
        insight.setText("RAM을 무조건 비우지 않고, 최근 사용하지 않은 앱만 골라 정리하고 있습니다...");
        worker.submit(() -> {
            RuleConfig rules = RuleConfig.load(this);
            List<AppCandidate> list = CandidateFinder.forRamBoost(this,rules);
            int killed=0;
            for (AppCandidate a:list) {
                if (killed>=12) break;
                if (PowerActions.killBackground(this,a.packageName)) killed++;
            }
            try { Thread.sleep(1800); } catch (InterruptedException ignored) {}
            SystemSnapshot after = SystemSnapshot.capture(this);
            long gained = Math.max(0, after.availRam-before.availRam);
            String msg = "RAM 정리 전 " + before.ramUsedPercent + "% → 정리 후 " + after.ramUsedPercent + "%\n" +
                    "확보된 RAM 약 " + SystemSnapshot.gb(gained) + " · 최근 쓰던 앱과 보호 앱은 유지했습니다.";
            if (killed==0) msg = "지금은 억지로 RAM을 비우는 것보다 그대로 두는 편이 낫습니다. 정리할 만한 오래된 앱이 거의 없습니다.";
            new GuardianDb(this).addAction("RAM","",msg,killed+"개 정리"); AppPrefs.setLastMessage(this,msg);
            String finalMsg=msg; runOnUiThread(() -> { insight.setText(finalMsg); refreshAll(); });
        });
    }

    private void startExperiment() {
        if (!UsageAccess.granted(this)) { explainNeedUsage(); return; }
        if (!shizuku.granted()) { handleShizuku(); return; }
        shizuku.ensureBound();
        if (!AppPrefs.autoManage(this)) { AppPrefs.setAutoManage(this,true); autoSwitch.setChecked(true); }
        boolean ok = ExperimentController.start(this);
        if (ok) {
            MonitorService.start(this);
            insight.setText("실험을 시작했습니다. 먼저 평소 사용량을 측정한 뒤 절약 설정을 잠깐 시험하고, 효과가 없으면 자동으로 원래대로 돌립니다.");
            refreshAll();
        } else toastDialog("실험 모드","사용 기록 권한과 Shizuku 연결을 먼저 확인해주세요.");
    }

    private void explainNeedUsage() {
        new AlertDialog.Builder(this).setTitle("사용 기록 권한이 필요합니다")
                .setMessage("어떤 앱을 자주 쓰는지 알아야 카카오톡 같은 중요한 앱은 건드리지 않고, 안 쓰는 앱만 골라서 제한할 수 있습니다.")
                .setPositiveButton("권한 설정 열기",(d,w)->startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)))
                .setNegativeButton("취소",null).show();
    }

    private void handleShizuku() {
        if (!shizuku.binderAlive()) {
            try {
                Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch != null) startActivity(launch); else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=moe.shizuku.privileged.api")));
            } catch (Exception e) { toastDialog("Shizuku","Shizuku를 먼저 실행해주세요."); }
        } else if (!shizuku.granted()) shizuku.requestPermission();
        else { shizuku.ensureBound(); refreshAll(); }
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4001);
    }
    private void seedProtectedDefaults() {
        if (AppPrefs.p(this).getBoolean("protected_seeded",false)) return;
        AppPrefs.setProtectedApps(this,CandidateFinder.defaultProtected(this));
        AppPrefs.p(this).edit().putBoolean("protected_seeded",true).apply();
    }
    private void toastDialog(String title,String msg) { new AlertDialog.Builder(this).setTitle(title).setMessage(msg==null?"":msg).setPositiveButton("확인",null).show(); }

    private LinearLayout col() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout card() { LinearLayout l=col(); l.setPadding(dp(16),dp(15),dp(16),dp(15)); GradientDrawable g=new GradientDrawable(); g.setColor(Color.WHITE); g.setCornerRadius(dp(18)); l.setBackground(g); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT); p.setMargins(0,0,0,dp(12)); l.setLayoutParams(p); l.setElevation(dp(1)); return l; }
    private TextView text(String s,int sp,boolean bold,int color) { TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color); v.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); v.setLineSpacing(0,1.12f); return v; }
    private TextView statCard(LinearLayout parent,String label,String value) { LinearLayout c=card(); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1); p.setMargins(0,0,dp(6),dp(10)); c.setLayoutParams(p); c.addView(text(label,13,false,Color.rgb(107,114,128))); TextView v=text(value,22,true,Color.rgb(23,32,51)); v.setPadding(0,dp(5),0,0); c.addView(v); parent.addView(c); return v; }
    private Button primaryButton(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setTextColor(Color.WHITE); b.setAllCaps(false); GradientDrawable g=new GradientDrawable(); g.setColor(Color.rgb(37,99,235)); g.setCornerRadius(dp(16)); b.setBackground(g); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(58)); p.setMargins(0,0,0,dp(10)); b.setLayoutParams(p); return b; }
    private Button secondaryButton(String s) { Button b=primaryButton(s); b.setTextColor(Color.rgb(29,78,216)); GradientDrawable g=new GradientDrawable(); g.setColor(Color.WHITE); g.setStroke(dp(1),Color.rgb(210,220,238)); g.setCornerRadius(dp(16)); b.setBackground(g); return b; }
    private Button smallButton(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(13); b.setAllCaps(false); b.setTextColor(Color.rgb(29,78,216)); return b; }
    private int dp(int v) { return Math.round(v*getResources().getDisplayMetrics().density); }
}
