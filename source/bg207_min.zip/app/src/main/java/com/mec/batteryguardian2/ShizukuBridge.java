package com.mec.batteryguardian2;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import rikka.shizuku.Shizuku;

public final class ShizukuBridge {
    public interface Callback { void onChanged(); }
    private static ShizukuBridge instance;
    public static synchronized ShizukuBridge get(Context c) {
        if (instance == null) instance = new ShizukuBridge(c.getApplicationContext());
        return instance;
    }

    private final Context context;
    private IPrivilegedService service;
    private boolean binding;
    private Callback callback;
    private final int REQ = 9001;

    private ShizukuBridge(Context c) {
        context = c;
        Shizuku.addBinderReceivedListenerSticky(() -> { binding = false; ensureBound(); fire(); });
        Shizuku.addBinderDeadListener(() -> { service = null; binding = false; fire(); });
        Shizuku.addRequestPermissionResultListener((requestCode, grantResult) -> { if (requestCode == REQ) { binding=false; ensureBound(); fire(); } });
    }

    public void setCallback(Callback c) { callback = c; }
    private void fire() { if (callback != null) callback.onChanged(); }
    public boolean binderAlive() { try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; } }
    public boolean granted() {
        try { return binderAlive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable t) { return false; }
    }
    public boolean ready() { return service != null; }
    public int remoteUid() { try { return service == null ? -1 : service.uid(); } catch (Exception e) { return -1; } }
    public void requestPermission() {
        try { if (binderAlive() && !granted()) Shizuku.requestPermission(REQ); } catch (Throwable ignored) {}
    }
    public void ensureBound() {
        if (!granted() || service != null || binding) return;
        try {
            binding = true;
            ComponentName cn = new ComponentName(context, PrivilegedUserService.class);
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(cn)
                    .processNameSuffix("guardian_priv")
                    .debuggable(false)
                    .version(1)
                    .daemon(true)
                    .tag("battery_guardian_2");
            Shizuku.bindUserService(args, connection);
        } catch (Throwable t) { binding = false; }
    }
    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            service = IPrivilegedService.Stub.asInterface(binder); binding = false; fire();
        }
        @Override public void onServiceDisconnected(ComponentName name) { service = null; binding = false; fire(); }
    };
    public String exec(String command) {
        if (service == null) return "ERROR=Shizuku service not ready";
        try { return service.exec(command); } catch (Exception e) { service = null; return "ERROR=" + e.getMessage(); }
    }
    public static boolean safePackage(String pkg) { return pkg != null && pkg.matches("[A-Za-z0-9_\\.]+") && pkg.length() < 220; }
}
