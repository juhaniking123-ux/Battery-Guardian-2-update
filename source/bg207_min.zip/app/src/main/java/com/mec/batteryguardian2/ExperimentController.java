package com.mec.batteryguardian2;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ExperimentController {
    private static final String P_PHASE="exp_phase", P_START="exp_start", P_CHARGE="exp_charge", P_BASE="exp_base", P_PKGS="exp_pkgs";
    private ExperimentController() {}

    public static String status(Context c) {
        int phase = AppPrefs.p(c).getInt(P_PHASE, 0);
        if (phase == 1) return "기준 사용량 측정 중";
        if (phase == 2) return "절약 설정 시험 중";
        return "대기";
    }

    public static boolean start(Context c) {
        if (!UsageAccess.granted(c) || !ShizukuBridge.get(c).ready()) return false;
        SharedPreferences p = AppPrefs.p(c);
        if (p.getInt(P_PHASE,0) != 0) return true;
        SystemSnapshot s = SystemSnapshot.capture(c);
        p.edit().putInt(P_PHASE,1).putLong(P_START,System.currentTimeMillis()).putLong(P_CHARGE,s.chargeCounterUah).putString(P_PKGS,"").apply();
        new GuardianDb(c).addAction("EXPERIMENT","","실험 모드를 시작했습니다. 먼저 평소 사용량을 측정합니다.","진행 중");
        AppPrefs.setLastMessage(c, "실험 모드: 먼저 평소 배터리 사용량을 측정하고 있습니다.");
        return true;
    }

    public static void tick(Context c) {
        SharedPreferences p = AppPrefs.p(c);
        int phase = p.getInt(P_PHASE,0);
        if (phase == 0) return;
        RuleConfig rules = RuleConfig.load(c);
        long start = p.getLong(P_START,0);
        long now = System.currentTimeMillis();
        int mins = phase == 1 ? rules.experimentBaselineMinutes : rules.experimentTestMinutes;
        if (now-start < mins*60_000L) return;
        SystemSnapshot s = SystemSnapshot.capture(c);
        long before = p.getLong(P_CHARGE,0);
        double drainUah = chargeDrain(before, s.chargeCounterUah);
        double perHour = drainUah * 60.0 / Math.max(1.0, mins);

        if (phase == 1) {
            List<AppCandidate> candidates = CandidateFinder.find(c, rules);
            List<String> pkgs = new ArrayList<>();
            int max = Math.min(4, candidates.size());
            for (int i=0;i<max;i++) {
                AppCandidate a = candidates.get(i);
                boolean ok = a.level >= 2 ? PowerActions.strong(c,a.packageName) : PowerActions.moderate(c,a.packageName);
                if (ok) pkgs.add(a.packageName);
            }
            if (pkgs.isEmpty()) {
                p.edit().putInt(P_PHASE,0).apply();
                AppPrefs.setLastMessage(c, "실험 종료: 안전하게 시험할 절약 후보가 없었습니다.");
                new GuardianDb(c).addAction("EXPERIMENT","","안전하게 시험할 절약 후보가 없어 종료했습니다.","변경 없음");
                return;
            }
            SharedPreferences.Editor e = p.edit(); putDoubleCompat(e,P_BASE,perHour); e.putInt(P_PHASE,2).putLong(P_START,now).putLong(P_CHARGE,s.chargeCounterUah).putString(P_PKGS,String.join(",",pkgs)).apply();
            AppPrefs.setLastMessage(c, "실험 모드: 절약 설정을 시험 중입니다. 효과가 없으면 자동으로 되돌립니다.");
        } else {
            double base = getDoubleCompat(p,P_BASE,0.0);
            double improvement = base > 1 ? (base-perHour)/base*100.0 : 0.0;
            String pkgCsv = p.getString(P_PKGS,"");
            if (improvement >= rules.keepImprovementPercent) {
                AppPrefs.setConfirmedSaving(c,(float)improvement);
                String m = String.format(Locale.KOREA,"실험 결과 실제 소모가 약 %.1f%% 줄어, 이 설정을 유지합니다.", improvement);
                AppPrefs.setLastMessage(c,m);
                new GuardianDb(c).addAction("EXPERIMENT","",m,"유지");
            } else {
                if (!pkgCsv.isEmpty()) for (String pkg : pkgCsv.split(",")) PowerActions.rollback(c,pkg);
                String m = "실험 결과 효과가 뚜렷하지 않아 시험 설정을 원래대로 돌렸습니다.";
                AppPrefs.setLastMessage(c,m);
                new GuardianDb(c).addAction("EXPERIMENT","",m,"복구");
            }
            p.edit().putInt(P_PHASE,0).remove(P_PKGS).apply();
        }
    }

    private static double chargeDrain(long before, long after) {
        if (before == 0 || after == 0) return 0.0;
        return Math.max(0.0, before-after);
    }
    private static void putDoubleCompat(SharedPreferences.Editor e,String k,double v) { e.putLong(k,Double.doubleToRawLongBits(v)); }
    private static double getDoubleCompat(SharedPreferences p,String k,double d) {
        long bits=p.getLong(k,Double.doubleToRawLongBits(d)); return Double.longBitsToDouble(bits);
    }
}
