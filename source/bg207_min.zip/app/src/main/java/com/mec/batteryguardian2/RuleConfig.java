package com.mec.batteryguardian2;

import android.content.Context;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public final class RuleConfig {
    public int rulesVersion = 1;
    public int sampleMinutes = 5;
    public int autoScanMinutes = 30;
    public int moderateUnusedHours = 72;
    public int strongUnusedHours = 336;
    public int ramBoostUnusedMinutes = 120;
    public int highDrainMa = 1500;
    public int veryHighDrainMa = 2500;
    public double highTempC = 39.0;
    public int experimentBaselineMinutes = 15;
    public int experimentTestMinutes = 15;
    public double keepImprovementPercent = 5.0;
    public int maxModerateAppsPerRun = 6;
    public int maxStrongAppsPerRun = 3;

    public static RuleConfig load(Context c) {
        RuleConfig r = new RuleConfig();
        File external = new File(c.getFilesDir(), "rules.json");
        try (InputStream raw = external.exists() ? new FileInputStream(external) : c.getAssets().open("rules_v200.json");
             BufferedReader br = new BufferedReader(new InputStreamReader(raw))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            JSONObject o = new JSONObject(sb.toString());
            r.rulesVersion = o.optInt("rulesVersion", r.rulesVersion);
            r.sampleMinutes = o.optInt("sampleMinutes", r.sampleMinutes);
            r.autoScanMinutes = o.optInt("autoScanMinutes", r.autoScanMinutes);
            r.moderateUnusedHours = o.optInt("moderateUnusedHours", r.moderateUnusedHours);
            r.strongUnusedHours = o.optInt("strongUnusedHours", r.strongUnusedHours);
            r.ramBoostUnusedMinutes = o.optInt("ramBoostUnusedMinutes", r.ramBoostUnusedMinutes);
            r.highDrainMa = o.optInt("highDrainMa", r.highDrainMa);
            r.veryHighDrainMa = o.optInt("veryHighDrainMa", r.veryHighDrainMa);
            r.highTempC = o.optDouble("highTempC", r.highTempC);
            r.experimentBaselineMinutes = o.optInt("experimentBaselineMinutes", r.experimentBaselineMinutes);
            r.experimentTestMinutes = o.optInt("experimentTestMinutes", r.experimentTestMinutes);
            r.keepImprovementPercent = o.optDouble("keepImprovementPercent", r.keepImprovementPercent);
            r.maxModerateAppsPerRun = o.optInt("maxModerateAppsPerRun", r.maxModerateAppsPerRun);
            r.maxStrongAppsPerRun = o.optInt("maxStrongAppsPerRun", r.maxStrongAppsPerRun);
        } catch (Exception ignored) {}
        return r;
    }
}
