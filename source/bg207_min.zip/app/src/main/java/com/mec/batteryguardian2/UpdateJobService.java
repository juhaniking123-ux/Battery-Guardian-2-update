package com.mec.batteryguardian2;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.net.NetworkCapabilities;

public class UpdateJobService extends JobService {
    private static final int JOB_ID = 260928;
    @Override public boolean onStartJob(JobParameters params) {
        UpdateManager.checkInBackground(this,false);
        jobFinished(params,false);
        return false;
    }
    @Override public boolean onStopJob(JobParameters params) { return false; }

    public static void schedule(Context c) {
        JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE); if(js==null)return;
        ComponentName cn=new ComponentName(c,UpdateJobService.class);
        JobInfo.Builder b=new JobInfo.Builder(JOB_ID,cn).setPersisted(true).setPeriodic(6L*60*60*1000);
        if(AppPrefs.wifiOnly(c)) b.setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED); else b.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
        js.schedule(b.build());
    }
    public static void cancel(Context c){JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(js!=null)js.cancel(JOB_ID);}
}
