package com.mec.batteryguardian2;

public final class AppCandidate {
    public String packageName;
    public String label;
    public long lastUsed;
    public long unusedMs;
    public int level;
    public AppCandidate(String packageName, String label, long lastUsed, long unusedMs, int level) {
        this.packageName = packageName; this.label = label; this.lastUsed = lastUsed; this.unusedMs = unusedMs; this.level = level;
    }
}
