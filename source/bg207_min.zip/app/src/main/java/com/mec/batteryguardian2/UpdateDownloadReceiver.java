package com.mec.batteryguardian2;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class UpdateDownloadReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i){ if(DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(i.getAction())) UpdateManager.handleDownloadComplete(c,i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID,-1)); }
}
