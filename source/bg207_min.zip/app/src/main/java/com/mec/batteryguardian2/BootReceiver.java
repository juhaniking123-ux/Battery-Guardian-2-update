package com.mec.batteryguardian2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            if (AppPrefs.autoManage(context)) { try { MonitorService.start(context); } catch (Exception ignored) {} }
            if (AppPrefs.autoUpdate(context)) { try { UpdateJobService.schedule(context); } catch (Exception ignored) {} }
        }
    }
}
