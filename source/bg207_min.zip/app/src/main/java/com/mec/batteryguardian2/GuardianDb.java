package com.mec.batteryguardian2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public final class GuardianDb extends SQLiteOpenHelper {
    private static final String DB = "guardian.db";
    public GuardianDb(Context c) { super(c, DB, null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE samples(ts INTEGER PRIMARY KEY, battery INTEGER, current_ma INTEGER, temp REAL, ram INTEGER, charge_uah INTEGER)");
        db.execSQL("CREATE TABLE actions(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, kind TEXT, target TEXT, message TEXT, result TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}
    public void addSample(SystemSnapshot s) {
        ContentValues v = new ContentValues();
        v.put("ts", s.capturedAt); v.put("battery", s.batteryPercent); v.put("current_ma", s.currentMa);
        v.put("temp", s.tempC); v.put("ram", s.ramUsedPercent); v.put("charge_uah", s.chargeCounterUah);
        getWritableDatabase().insertWithOnConflict("samples", null, v, SQLiteDatabase.CONFLICT_REPLACE);
        getWritableDatabase().delete("samples", "ts < ?", new String[]{String.valueOf(System.currentTimeMillis()-14L*24*3600*1000)});
    }
    public void addAction(String kind, String target, String message, String result) {
        ContentValues v = new ContentValues(); v.put("ts", System.currentTimeMillis()); v.put("kind", kind);
        v.put("target", target); v.put("message", message); v.put("result", result);
        getWritableDatabase().insert("actions", null, v);
    }
    public List<String> recentActions(int limit) {
        List<String> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT ts,kind,message,result FROM actions ORDER BY id DESC LIMIT " + Math.max(1, limit), null);
        try {
            while (c.moveToNext()) {
                String k = c.getString(1); String m = c.getString(2); String r = c.getString(3);
                String prefix = (k == null || k.isEmpty()) ? "" : "[" + k + "] ";
                out.add("• " + prefix + m + (r == null || r.isEmpty() ? "" : "  ·  " + r));
            }
        } finally { c.close(); }
        return out;
    }
}
