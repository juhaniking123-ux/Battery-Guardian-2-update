package com.mec.batteryguardian2;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Lightweight battery-change detector.
 *
 * It does NOT guess that every 1% drop means a broken battery. The first fast
 * percentage change is only recorded. An update check is triggered only after
 * a repeated/aggregate fast-drop pattern, with a long cooldown so monitoring
 * itself stays cheap.
 */
public final class AnomalyDetector {
    private static final String LAST_PERCENT = "detect_last_percent";
    private static final String LAST_AT = "detect_last_at";
    private static final String FAST_COUNT = "detect_fast_count";
    private static final String LAST_ANOMALY_AT = "detect_last_anomaly_at";
    private static final String LAST_ANOMALY_TEXT = "detect_last_anomaly_text";
    private static final String FULL_START_AT = "detect_full_start_at";
    private static final String LAST_CHARGING = "detect_last_charging";

    private static final long FAST_DROP_LIMIT_MS = 5L * 60_000L;   // <= 5 min / 1%
    private static final long ANOMALY_COOLDOWN_MS = 6L * 60L * 60_000L;

    private AnomalyDetector() {}

    public static void observe(Context c, SystemSnapshot s) {
        if (s == null || s.batteryPercent < 0) return;
        SharedPreferences p = AppPrefs.p(c);
        long now = s.capturedAt > 0 ? s.capturedAt : System.currentTimeMillis();

        if (s.charging) {
            SharedPreferences.Editor e = p.edit()
                    .putInt(LAST_PERCENT, s.batteryPercent)
                    .putLong(LAST_AT, now)
                    .putInt(FAST_COUNT, 0)
                    .putBoolean(LAST_CHARGING, true);
            if (s.batteryPercent >= 100) e.putLong(FULL_START_AT, now);
            e.apply();
            return;
        }

        boolean wasCharging = p.getBoolean(LAST_CHARGING, false);
        int prev = p.getInt(LAST_PERCENT, -1);
        long prevAt = p.getLong(LAST_AT, 0L);
        if (wasCharging) {
            // Start the discharge clock from cable removal, not from the last
            // 100% sample while the phone was still sitting on the charger.
            p.edit().putBoolean(LAST_CHARGING, false).putInt(LAST_PERCENT, s.batteryPercent)
                    .putLong(LAST_AT, now).putInt(FAST_COUNT, 0).apply();
            return;
        }
        if (prev < 0 || prevAt <= 0L || s.batteryPercent > prev) {
            p.edit().putInt(LAST_PERCENT, s.batteryPercent).putLong(LAST_AT, now).putInt(FAST_COUNT, 0).apply();
            return;
        }

        if (s.batteryPercent == prev) return;

        int drop = prev - s.batteryPercent;
        long elapsed = Math.max(1L, now - prevAt);
        double perPercentMs = elapsed / (double)Math.max(1, drop);
        int fastCount = p.getInt(FAST_COUNT, 0);

        if (perPercentMs <= FAST_DROP_LIMIT_MS) {
            fastCount += drop;
            String msg = "빠른 배터리 변화 기록: " + prev + "% → " + s.batteryPercent + "% · " + duration(elapsed);
            new GuardianDb(c).addAction("감지", "battery", msg, fastCount >= 2 ? "재확인 필요" : "1차 기록");
        } else {
            fastCount = 0;
        }

        p.edit().putInt(LAST_PERCENT, s.batteryPercent).putLong(LAST_AT, now).putInt(FAST_COUNT, fastCount).apply();

        // A single quick 100 -> 99 change can be fuel-gauge calibration. Require
        // two quick percent drops, or a sustained full-charge average pattern.
        boolean repeatedFast = fastCount >= 2;
        boolean sustainedFast = false;
        long fullStart = p.getLong(FULL_START_AT, 0L);
        int totalDrop = Math.max(0, 100 - s.batteryPercent);
        if (fullStart > 0L && totalDrop >= 3) {
            long totalElapsed = Math.max(1L, now - fullStart);
            double avgMinPerPercent = totalElapsed / 60_000.0 / totalDrop;
            sustainedFast = avgMinPerPercent <= 7.0;
        }

        if (repeatedFast || sustainedFast) {
            trigger(c, s, repeatedFast ? "짧은 시간에 배터리 감소가 반복됨" : "완충 후 평균 감소 속도가 빠름");
            p.edit().putInt(FAST_COUNT, 0).apply();
        }
    }

    private static void trigger(Context c, SystemSnapshot s, String reason) {
        SharedPreferences p = AppPrefs.p(c);
        long now = System.currentTimeMillis();
        long last = p.getLong(LAST_ANOMALY_AT, 0L);
        if (now - last < ANOMALY_COOLDOWN_MS) return;

        String text = "배터리 이상 변화 감지: " + reason + " · 현재 " + s.batteryPercent + "%" +
                (s.currentMa > 0 ? " · " + s.currentMa + "mA" : "") + ". 로그를 기록하고 새 업데이트가 있는지 자동 확인합니다.";
        p.edit().putLong(LAST_ANOMALY_AT, now).putString(LAST_ANOMALY_TEXT, text).apply();
        AppPrefs.setLastMessage(c, text);
        new GuardianDb(c).addAction("감지", "battery", text, "업데이트 확인");
        UpdateManager.checkBecauseOfAnomaly(c);
    }

    public static String lastStatus(Context c) {
        return AppPrefs.p(c).getString(LAST_ANOMALY_TEXT, "아직 이상 변화가 감지되지 않았습니다.");
    }

    private static String duration(long ms) {
        long sec = Math.max(1L, ms / 1000L);
        if (sec < 60) return sec + "초";
        long min = sec / 60L;
        long remain = sec % 60L;
        return min + "분" + (remain > 0 ? " " + remain + "초" : "");
    }
}
