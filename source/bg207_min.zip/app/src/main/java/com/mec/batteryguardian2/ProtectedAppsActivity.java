package com.mec.batteryguardian2;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ProtectedAppsActivity extends Activity {
    private final List<String> packages = new ArrayList<>();
    private final List<String> labels = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private ListView list;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        selected.addAll(AppPrefs.protectedApps(this));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(16),dp(16),dp(16)); root.setBackgroundColor(Color.rgb(246,248,252));
        TextView t = new TextView(this); t.setText("보호 앱"); t.setTextSize(24); t.setTextColor(Color.rgb(23,32,51)); t.setTypeface(null,1); root.addView(t);
        TextView d = new TextView(this); d.setText("알림이 꼭 필요한 앱이나 자주 쓰는 앱을 체크하세요. 보호 앱은 자동 제한과 RAM 부스트에서 제외합니다."); d.setTextSize(14); d.setTextColor(Color.rgb(95,105,120)); d.setPadding(0,dp(6),0,dp(12)); root.addView(d);
        list = new ListView(this); list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE); root.addView(list,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        Button save = new Button(this); save.setText("저장"); save.setAllCaps(false); save.setOnClickListener(v->{ save(); finish(); }); root.addView(save,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(54)));
        setContentView(root);
        loadApps();
    }

    private void loadApps() {
        PackageManager pm=getPackageManager();
        List<ApplicationInfo> apps;
        try { apps=pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0)); } catch(Throwable e){ apps=pm.getInstalledApplications(0); }
        List<ApplicationInfo> user=new ArrayList<>();
        for(ApplicationInfo a:apps) if((a.flags&ApplicationInfo.FLAG_SYSTEM)==0 && !a.packageName.equals(getPackageName())) user.add(a);
        user.sort(Comparator.comparing(a->{ try{return pm.getApplicationLabel(a).toString().toLowerCase();}catch(Exception e){return a.packageName;} }));
        for(ApplicationInfo a:user){ packages.add(a.packageName); String label; try{label=pm.getApplicationLabel(a).toString();}catch(Exception e){label=a.packageName;} labels.add(label+"\n"+a.packageName); }
        list.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_multiple_choice,labels));
        for(int i=0;i<packages.size();i++) if(selected.contains(packages.get(i))) list.setItemChecked(i,true);
    }
    private void save(){
        Set<String> out=new HashSet<>(CandidateFinder.defaultProtected(this));
        for(int i=0;i<packages.size();i++) if(list.isItemChecked(i)) out.add(packages.get(i));
        AppPrefs.setProtectedApps(this,out);
    }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
