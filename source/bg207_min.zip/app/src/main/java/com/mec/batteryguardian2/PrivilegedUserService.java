package com.mec.batteryguardian2;

import android.content.Context;
import android.os.Process;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

public class PrivilegedUserService extends IPrivilegedService.Stub {
    public PrivilegedUserService() {}
    public PrivilegedUserService(Context context) {}

    @Override public void destroy() { System.exit(0); }
    @Override public int uid() { return Process.myUid(); }

    @Override public String exec(String command) {
        StringBuilder sb = new StringBuilder();
        try {
            java.lang.Process p = new ProcessBuilder("/system/bin/sh", "-c", command).redirectErrorStream(true).start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            boolean done = p.waitFor(25, TimeUnit.SECONDS);
            if (!done) { p.destroyForcibly(); return "TIMEOUT"; }
            return "EXIT=" + p.exitValue() + "\n" + sb.toString().trim();
        } catch (Exception e) {
            return "ERROR=" + e.getClass().getSimpleName() + ":" + e.getMessage();
        }
    }
}
