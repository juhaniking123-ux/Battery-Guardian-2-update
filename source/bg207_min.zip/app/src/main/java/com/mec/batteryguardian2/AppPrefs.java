package com.mec.batteryguardian2;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public final class AppPrefs {
    private static final String NAME = "guardian_prefs";
    private AppPrefs() {}
    public static SharedPreferences p(Context c) { return c.getSharedPreferences(NAME, Context.MODE_PRIVATE); }
    public static boolean autoManage(Context c) { return p(c).getBoolean("auto_manage", false); }
    public static void setAutoManage(Context c, boolean v) { p(c).edit().putBoolean("auto_manage", v).apply(); }
    public static boolean autoUpdate(Context c) { return p(c).getBoolean("auto_update", false); }
    public static boolean wifiOnly(Context c) { return p(c).getBoolean("wifi_only", false); }
    public static boolean screenOffOnly(Context c) { return p(c).getBoolean("screen_off_only", true); }
    public static String updateFeed(Context c) { return p(c).getString("update_feed", "https://raw.githubusercontent.com/juhaniking123-ux/Battery-Guardian-2-update/main/update.json"); }
    public static Set<String> protectedApps(Context c) {
        Set<String> s = p(c).getStringSet("protected_apps", Collections.emptySet());
        return new HashSet<>(s);
    }
    public static void setProtectedApps(Context c, Set<String> s) {
        p(c).edit().putStringSet("protected_apps", new HashSet<>(s)).apply();
    }
    public static long lastAutoScan(Context c) { return p(c).getLong("last_auto_scan", 0L); }
    public static void setLastAutoScan(Context c, long t) { p(c).edit().putLong("last_auto_scan", t).apply(); }
    public static String lastMessage(Context c) { return p(c).getString("last_message", "아직 자동 조치 기록이 없습니다."); }
    public static void setLastMessage(Context c, String m) { p(c).edit().putString("last_message", m).apply(); }
    public static float confirmedSaving(Context c) { return p(c).getFloat("confirmed_saving", -1f); }
    public static void setConfirmedSaving(Context c, float v) { p(c).edit().putFloat("confirmed_saving", v).apply(); }
}
