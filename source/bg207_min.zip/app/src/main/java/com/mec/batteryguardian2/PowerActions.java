package com.mec.batteryguardian2;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;

public final class PowerActions {
    private PowerActions() {}
    private static String key(String type, String pkg) { return "rb_" + type + "_" + pkg; }

    public static boolean moderate(Context c, String pkg) {
        if (!ShizukuBridge.safePackage(pkg)) return false;
        ShizukuBridge b = ShizukuBridge.get(c); if (!b.ready()) return false;
        saveBefore(c, pkg);
        String r = b.exec("am set-standby-bucket " + pkg + " rare");
        boolean success=ok(r); if(success) markManaged(c,pkg);
        String name = appLabel(c,pkg);
        new GuardianDb(c).addAction("백그라운드 일반", pkg, name + ": 대기 상태를 조정해 백그라운드 활동 빈도를 줄였습니다.", success?"완료":"실패");
        return success;
    }
    public static boolean strong(Context c, String pkg) {
        if (!ShizukuBridge.safePackage(pkg)) return false;
        ShizukuBridge b = ShizukuBridge.get(c); if (!b.ready()) return false;
        saveBefore(c, pkg);
        String r = b.exec("am set-standby-bucket " + pkg + " rare; cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND ignore; cmd appops set " + pkg + " WAKE_LOCK ignore");
        boolean success=ok(r); if(success) markManaged(c,pkg);
        String name = appLabel(c,pkg);
        new GuardianDb(c).addAction("백그라운드 강함", pkg, name + ": 백그라운드 실행과 불필요한 Wake Lock을 제한했습니다.", success?"완료":"실패");
        return success;
    }
    public static boolean killBackground(Context c, String pkg) {
        if (!ShizukuBridge.safePackage(pkg)) return false;
        ShizukuBridge b = ShizukuBridge.get(c); if (!b.ready()) return false;
        String r = b.exec("am kill --user current " + pkg);
        return ok(r);
    }
    public static boolean rollback(Context c, String pkg) {
        if (!ShizukuBridge.safePackage(pkg)) return false;
        ShizukuBridge b = ShizukuBridge.get(c); if (!b.ready()) return false;
        SharedPreferences p = AppPrefs.p(c);
        String bucket = p.getString(key("bucket",pkg), "active");
        String appop = p.getString(key("appop",pkg), "allow");
        String wake = p.getString(key("wake",pkg), "allow");
        if (!bucket.matches("active|working_set|frequent|rare|restricted")) bucket = "active";
        if (!appop.matches("allow|ignore|default|foreground")) appop = "allow";
        if (!wake.matches("allow|ignore|default|foreground")) wake = "allow";
        String r = b.exec("am set-standby-bucket " + pkg + " " + bucket + "; cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND " + appop + "; cmd appops set " + pkg + " WAKE_LOCK " + wake);
        boolean success=ok(r); if(success) { unmarkManaged(c,pkg); p.edit().remove(key("bucket",pkg)).remove(key("appop",pkg)).remove(key("wake",pkg)).apply(); }
        new GuardianDb(c).addAction("ROLLBACK", pkg, "시험 설정을 원래대로 돌렸습니다.", success?"완료":"실패");
        return success;
    }
    private static void saveBefore(Context c, String pkg) {
        SharedPreferences p = AppPrefs.p(c);
        if (p.contains(key("bucket",pkg))) return;
        ShizukuBridge b = ShizukuBridge.get(c);
        String bucketOut = b.exec("am get-standby-bucket " + pkg);
        String appOut = b.exec("cmd appops get " + pkg + " RUN_ANY_IN_BACKGROUND");
        String wakeOut = b.exec("cmd appops get " + pkg + " WAKE_LOCK");
        String bucket = parseBucket(bucketOut);
        String appop = parseAppOp(appOut);
        String wake = parseAppOp(wakeOut);
        p.edit().putString(key("bucket",pkg), bucket).putString(key("appop",pkg), appop).putString(key("wake",pkg), wake).apply();
    }
    private static String parseBucket(String s) {
        if (s == null) return "active";
        String low = s.toLowerCase(Locale.ROOT);
        if (low.contains("restricted") || low.matches("(?s).*\\b45\\b.*")) return "restricted";
        if (low.contains("rare") || low.matches("(?s).*\\b40\\b.*")) return "rare";
        if (low.contains("frequent") || low.matches("(?s).*\\b30\\b.*")) return "frequent";
        if (low.contains("working") || low.matches("(?s).*\\b20\\b.*")) return "working_set";
        return "active";
    }
    private static String parseAppOp(String s) {
        if (s == null) return "allow";
        String low = s.toLowerCase(Locale.ROOT);
        if (low.contains("ignore")) return "ignore";
        if (low.contains("foreground")) return "foreground";
        if (low.contains("default")) return "default";
        return "allow";
    }
    private static boolean ok(String s) { return s != null && (s.contains("EXIT=0") || s.trim().equals("")); }

    private static void markManaged(Context c,String pkg){
        SharedPreferences p=AppPrefs.p(c); Set<String>s=new HashSet<>(p.getStringSet("managed_pkgs",new HashSet<>())); s.add(pkg); p.edit().putStringSet("managed_pkgs",s).putLong("managed_at_"+pkg,System.currentTimeMillis()).apply();
    }
    private static void unmarkManaged(Context c,String pkg){
        SharedPreferences p=AppPrefs.p(c); Set<String>s=new HashSet<>(p.getStringSet("managed_pkgs",new HashSet<>())); s.remove(pkg); p.edit().putStringSet("managed_pkgs",s).remove("managed_at_"+pkg).apply();
    }
    public static int managedCount(Context c) {
        return AppPrefs.p(c).getStringSet("managed_pkgs", new HashSet<>()).size();
    }
    public static Set<String> managedPackages(Context c) {
        return new HashSet<>(AppPrefs.p(c).getStringSet("managed_pkgs", new HashSet<>()));
    }
    private static String appLabel(Context c,String pkg) {
        try {
            android.content.pm.PackageManager pm=c.getPackageManager();
            android.content.pm.ApplicationInfo ai=pm.getApplicationInfo(pkg,0);
            return pm.getApplicationLabel(ai).toString();
        } catch(Exception e) { return pkg; }
    }

    public static int restoreReusedApps(Context c){
        if(!UsageAccess.granted(c)||!ShizukuBridge.get(c).ready())return 0;
        SharedPreferences p=AppPrefs.p(c); Set<String>s=new HashSet<>(p.getStringSet("managed_pkgs",new HashSet<>())); if(s.isEmpty())return 0;
        Map<String,Long> last=UsageAccess.lastUsed(c,30L*24*3600*1000); int n=0;
        for(String pkg:new HashSet<>(s)){ long at=p.getLong("managed_at_"+pkg,0); long used=last.containsKey(pkg)?last.get(pkg):0; if(at>0&&used>at+60_000L){ if(rollback(c,pkg))n++; } }
        if(n>0) AppPrefs.setLastMessage(c,"전에 제한했던 앱을 다시 사용한 것이 확인되어 해당 앱은 자동으로 정상 상태로 돌렸습니다.");
        return n;
    }
    public static int rollbackAll(Context c){
        SharedPreferences p=AppPrefs.p(c); Set<String>s=new HashSet<>(p.getStringSet("managed_pkgs",new HashSet<>())); int n=0; for(String pkg:new HashSet<>(s))if(rollback(c,pkg))n++; return n;
    }

}
