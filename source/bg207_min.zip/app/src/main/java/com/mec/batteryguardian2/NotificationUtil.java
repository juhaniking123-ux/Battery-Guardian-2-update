package com.mec.batteryguardian2;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class NotificationUtil {
    public static final String CH_MONITOR = "guardian_monitor";
    public static final String CH_ALERT = "guardian_alert";
    private NotificationUtil() {}

    public static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel m = new NotificationChannel(CH_MONITOR, "Battery Guardian 자동 관리", NotificationManager.IMPORTANCE_LOW);
        m.setDescription("배터리와 RAM 상태를 낮은 빈도로 확인합니다.");
        m.setShowBadge(false);
        nm.createNotificationChannel(m);
        NotificationChannel a = new NotificationChannel(CH_ALERT, "Battery Guardian 알림", NotificationManager.IMPORTANCE_DEFAULT);
        a.setDescription("자동 해결 결과와 업데이트를 알려줍니다.");
        nm.createNotificationChannel(a);
    }

    public static Notification monitor(Context c, String text) {
        ensureChannels(c);
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 100, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(c, CH_MONITOR)
                .setSmallIcon(R.drawable.ic_battery)
                .setContentTitle("Battery Guardian 2 자동 관리")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    public static void alert(Context c, int id, String title, String text) {
        ensureChannels(c);
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CH_ALERT)
                .setSmallIcon(R.drawable.ic_battery)
                .setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true).setContentIntent(pi).build();
        nm.notify(id, n);
    }
}
