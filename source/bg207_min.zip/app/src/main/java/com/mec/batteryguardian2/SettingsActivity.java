package com.mec.batteryguardian2;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class SettingsActivity extends Activity {
    private TextView updateStatus;
    private EditText feed;
    private Switch autoUpdate,wifiOnly,screenOff;

    @Override protected void onCreate(Bundle b){ super.onCreate(b); setContentView(build()); }
    private LinearLayout build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(24)); root.setBackgroundColor(Color.rgb(246,248,252));
        TextView t=tx("설정 / 업데이트",25,true); root.addView(t);
        root.addView(tx("업데이트는 강제로 하지 않고, 추천 알림 또는 선택한 조건에서만 자동 처리합니다. 배터리 이상 변화가 반복 감지되면 로그를 남기고 새 버전이 있는지도 자동 확인합니다.",14,false));
        autoUpdate=sw("스마트 자동 업데이트",AppPrefs.autoUpdate(this)); root.addView(autoUpdate);
        wifiOnly=sw("업데이트는 Wi‑Fi에서만 (OFF 시 모바일 데이터 허용)",AppPrefs.wifiOnly(this)); root.addView(wifiOnly);
        screenOff=sw("자동 업데이트는 화면이 꺼져 있을 때만",AppPrefs.screenOffOnly(this)); root.addView(screenOff);
        TextView l=tx("업데이트 주소",15,true); l.setPadding(0,dp(14),0,dp(4)); root.addView(l);
        feed=new EditText(this); feed.setSingleLine(false); feed.setMinLines(2); feed.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI); feed.setText(AppPrefs.updateFeed(this)); feed.setHint("업데이트 manifest.json 주소"); root.addView(feed,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        updateStatus=tx(AppPrefs.p(this).getString("update_status","업데이트 채널이 아직 연결되지 않았습니다."),13,false); updateStatus.setPadding(0,dp(8),0,dp(8)); root.addView(updateStatus);
        Button save=new Button(this); save.setText("설정 저장"); save.setAllCaps(false); save.setOnClickListener(v->save(true)); root.addView(save);
        Button check=new Button(this); check.setText("지금 업데이트 확인"); check.setAllCaps(false); check.setOnClickListener(v->{save(false); updateStatus.setText("업데이트 확인 중..."); UpdateManager.checkInBackground(this,true);}); root.addView(check);
        Button rollback=new Button(this); rollback.setText("자동 제한 모두 원래대로 복구"); rollback.setAllCaps(false); rollback.setOnClickListener(v->{ new Thread(()->{ int n=PowerActions.rollbackAll(this); runOnUiThread(()->new AlertDialog.Builder(this).setMessage(n+"개 앱을 원래 상태로 복구했습니다.").setPositiveButton("확인",null).show()); }).start(); }); root.addView(rollback);
        Button close=new Button(this); close.setText("닫기"); close.setAllCaps(false); close.setOnClickListener(v->finish()); root.addView(close);
        return root;
    }
    private void save(boolean showMessage){
        AppPrefs.p(this).edit().putBoolean("auto_update",autoUpdate.isChecked()).putBoolean("wifi_only",wifiOnly.isChecked()).putBoolean("screen_off_only",screenOff.isChecked()).putString("update_feed",feed.getText().toString().trim()).apply();
        if(autoUpdate.isChecked()) UpdateJobService.schedule(this); else UpdateJobService.cancel(this);
        if(showMessage) new AlertDialog.Builder(this).setMessage("저장했습니다.").setPositiveButton("확인",null).show();
    }
    @Override protected void onResume(){super.onResume(); if(updateStatus!=null) updateStatus.setText(AppPrefs.p(this).getString("update_status","업데이트 채널이 아직 연결되지 않았습니다."));}
    private Switch sw(String s,boolean c){Switch v=new Switch(this);v.setText(s);v.setTextSize(15);v.setTextColor(Color.rgb(23,32,51));v.setChecked(c);v.setPadding(0,dp(10),0,dp(10));return v;}
    private TextView tx(String s,int sp,boolean b){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(b?Color.rgb(23,32,51):Color.rgb(95,105,120));if(b)v.setTypeface(null,1);v.setLineSpacing(0,1.15f);return v;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
