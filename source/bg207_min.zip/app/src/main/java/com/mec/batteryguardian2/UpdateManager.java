package com.mec.batteryguardian2;

import android.app.DownloadManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Environment;
import android.os.PowerManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;

public final class UpdateManager {
    private static final String KEY_LAST_CHECK="update_last_check";
    private UpdateManager() {}

    public static void checkInBackground(Context c, boolean userInitiated) {
        checkInBackground(c, userInitiated, false);
    }

    public static void checkBecauseOfAnomaly(Context c) {
        String feed=AppPrefs.updateFeed(c);
        if(feed==null||feed.trim().isEmpty()) {
            AppPrefs.p(c).edit().putString("update_status","배터리 변화는 감지했지만 업데이트 주소가 아직 연결되지 않았습니다.").apply();
            return;
        }
        checkInBackground(c, false, true);
    }

    private static void checkInBackground(Context c, boolean userInitiated, boolean force) {
        String feed=AppPrefs.updateFeed(c);
        if(feed==null||feed.trim().isEmpty()) {
            AppPrefs.p(c).edit().putString("update_status","업데이트 채널이 아직 연결되지 않았습니다. 업데이트 주소를 등록하면 추천 알림과 자동 업데이트를 사용할 수 있습니다.").apply();
            return;
        }
        long now=System.currentTimeMillis();
        if(!force && !userInitiated && now-AppPrefs.p(c).getLong(KEY_LAST_CHECK,0)<6*3600_000L) return;
        new Thread(()->{
            try {
                JSONObject o=fetchJson(feed);
                AppPrefs.p(c).edit().putLong(KEY_LAST_CHECK,System.currentTimeMillis()).apply();
                int vc=o.optInt("versionCode",0);
                String vn=o.optString("versionName","");
                String rulesUrl=o.optString("rulesUrl","");
                if(!rulesUrl.isEmpty()) tryUpdateRules(c,rulesUrl);
                if(vc>BuildConfig.VERSION_CODE){
                    String title=o.optString("title","새로운 업데이트가 있습니다");
                    String notes=joinNotes(o.optJSONArray("notes"));
                    AppPrefs.p(c).edit().putString("update_status",title+" · v"+vn+"\n"+notes).putString("pending_apk_url",o.optString("apkUrl","")).putString("pending_sha256",o.optString("sha256","")).putString("pending_version",vn).apply();
                    if(AppPrefs.autoUpdate(c)&&conditionsOk(c)) {
                        enqueueDownload(c,o.optString("apkUrl",""),o.optString("sha256",""),vn,true);
                    } else notifyAvailable(c,title,"v"+vn+" · "+notes);
                } else {
                    AppPrefs.p(c).edit().putString("update_status","현재 최신 버전입니다. (v"+BuildConfig.VERSION_NAME+")").apply();
                    if(userInitiated) NotificationUtil.alert(c,2202,"업데이트 확인","현재 최신 버전입니다.");
                }
            }catch(Exception e){
                AppPrefs.p(c).edit().putString("update_status","업데이트 확인 실패: "+safe(e.getMessage())).apply();
                if(userInitiated) NotificationUtil.alert(c,2203,"업데이트 확인 실패","인터넷 또는 업데이트 주소를 확인해주세요.");
            }
        },"UpdateCheck").start();
    }

    private static void notifyAvailable(Context c,String title,String text){
        NotificationUtil.ensureChannels(c);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(nm==null)return;
        Intent open=new Intent(c,SettingsActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,3301,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent dl=new Intent(c,UpdateActionReceiver.class).setAction("com.mec.batteryguardian2.DOWNLOAD_UPDATE");
        PendingIntent dpi=PendingIntent.getBroadcast(c,3302,dl,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(c,NotificationUtil.CH_ALERT).setSmallIcon(R.drawable.ic_battery).setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setContentIntent(pi).addAction(new Notification.Action.Builder(R.drawable.ic_battery,"업데이트",dpi).build()).addAction(new Notification.Action.Builder(R.drawable.ic_battery,"나중에",pi).build()).setAutoCancel(true).build();
        nm.notify(3300,n);
    }

    public static void downloadPending(Context c,boolean auto){
        String url=AppPrefs.p(c).getString("pending_apk_url",""); String sha=AppPrefs.p(c).getString("pending_sha256",""); String vn=AppPrefs.p(c).getString("pending_version","");
        enqueueDownload(c,url,sha,vn,auto);
    }

    private static void enqueueDownload(Context c,String url,String sha,String vn,boolean auto){
        if(url==null||url.isEmpty()) { AppPrefs.p(c).edit().putString("update_status","업데이트 파일 주소가 없습니다.").apply(); return; }
        try {
            DownloadManager dm=(DownloadManager)c.getSystemService(Context.DOWNLOAD_SERVICE); if(dm==null)return;
            String file="BatteryGuardian2/Battery_Guardian_2_v"+(vn.isEmpty()?"new":vn)+".apk";
            DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url)).setTitle("Battery Guardian 2 업데이트").setDescription("새 버전을 준비하고 있습니다.").setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE).setAllowedOverMetered(!AppPrefs.wifiOnly(c)).setAllowedOverRoaming(false).setMimeType("application/vnd.android.package-archive").setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,file);
            long id=dm.enqueue(r);
            AppPrefs.p(c).edit().putLong("update_download_id",id).putString("update_download_sha",sha==null?"":sha).putString("update_download_path",new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),file).getAbsolutePath()).putBoolean("update_download_auto",auto).putString("update_status","업데이트 다운로드 중...").apply();
        }catch(Exception e){ AppPrefs.p(c).edit().putString("update_status","업데이트 다운로드 실패: "+safe(e.getMessage())).apply(); }
    }

    public static void handleDownloadComplete(Context c,long id){
        if(id!=AppPrefs.p(c).getLong("update_download_id",-1)) return;
        DownloadManager dm=(DownloadManager)c.getSystemService(Context.DOWNLOAD_SERVICE); if(dm==null)return;
        Cursor cur=dm.query(new DownloadManager.Query().setFilterById(id));
        int status=-1; Uri uri=null;
        try{ if(cur!=null&&cur.moveToFirst()){status=cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)); uri=dm.getUriForDownloadedFile(id);} }finally{if(cur!=null)cur.close();}
        if(status!=DownloadManager.STATUS_SUCCESSFUL||uri==null){AppPrefs.p(c).edit().putString("update_status","업데이트 다운로드에 실패했습니다.").apply();return;}
        String expected=AppPrefs.p(c).getString("update_download_sha","");
        try{
            if(!expected.isEmpty()&&!expected.equalsIgnoreCase(sha256(c,uri))){AppPrefs.p(c).edit().putString("update_status","업데이트 파일 검증에 실패했습니다. 설치하지 않았습니다.").apply();NotificationUtil.alert(c,3310,"업데이트 중단","파일 검증 값이 맞지 않아 설치하지 않았습니다.");return;}
        }catch(Exception e){AppPrefs.p(c).edit().putString("update_status","업데이트 파일 검증 실패").apply();return;}
        boolean auto=AppPrefs.p(c).getBoolean("update_download_auto",false);
        String path=AppPrefs.p(c).getString("update_download_path","");
        final Uri downloadUri = uri;
        if(auto&&conditionsOk(c)&&ShizukuBridge.get(c).ready()&&path.matches("[A-Za-z0-9_\\-\\./ ]+")){
            new Thread(()->{
                String q="pm install -r \""+path.replace("\"","")+"\"";
                String out=ShizukuBridge.get(c).exec(q);
                if(out!=null&&out.toLowerCase(Locale.ROOT).contains("success")) AppPrefs.p(c).edit().putString("update_status","업데이트 설치 완료").apply();
                else {AppPrefs.p(c).edit().putString("update_status","자동 설치 확인이 필요합니다.").apply(); launchInstaller(c,downloadUri);}
            }).start();
        }else launchInstaller(c,downloadUri);
    }

    private static void launchInstaller(Context c,Uri uri){
        try{Intent i=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);}catch(Exception e){NotificationUtil.alert(c,3311,"업데이트 준비 완료","다운로드 폴더의 Battery Guardian 2 APK를 눌러 설치해주세요.");}
    }
    private static boolean conditionsOk(Context c){
        if(AppPrefs.wifiOnly(c)&&!wifi(c))return false;
        if(AppPrefs.screenOffOnly(c)){PowerManager p=(PowerManager)c.getSystemService(Context.POWER_SERVICE);if(p!=null&&p.isInteractive())return false;}
        return true;
    }
    private static boolean wifi(Context c){ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);if(cm==null)return false;Network n=cm.getActiveNetwork();if(n==null)return false;NetworkCapabilities nc=cm.getNetworkCapabilities(n);return nc!=null&&nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);}
    private static JSONObject fetchJson(String u)throws Exception{HttpURLConnection h=(HttpURLConnection)new URL(u).openConnection();h.setConnectTimeout(8000);h.setReadTimeout(8000);h.setRequestProperty("User-Agent","BatteryGuardian2/"+BuildConfig.VERSION_NAME);try(BufferedReader br=new BufferedReader(new InputStreamReader(h.getInputStream()))){StringBuilder s=new StringBuilder();String l;while((l=br.readLine())!=null)s.append(l);return new JSONObject(s.toString());}finally{h.disconnect();}}
    private static void tryUpdateRules(Context c,String url){try{HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setConnectTimeout(7000);h.setReadTimeout(7000);try(BufferedInputStream in=new BufferedInputStream(h.getInputStream());FileOutputStream out=new FileOutputStream(new File(c.getFilesDir(),"rules.json"))){byte[]b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}finally{h.disconnect();}}catch(Exception ignored){}}
    private static String sha256(Context c,Uri u)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");try(BufferedInputStream in=new BufferedInputStream(c.getContentResolver().openInputStream(u))){byte[]b=new byte[8192];int n;while((n=in.read(b))>0)md.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte x:md.digest())s.append(String.format(Locale.US,"%02x",x));return s.toString();}
    private static String joinNotes(JSONArray a){if(a==null||a.length()==0)return "개선 사항을 확인할 수 있습니다.";StringBuilder s=new StringBuilder();for(int i=0;i<a.length();i++){if(i>0)s.append(" · ");s.append(a.optString(i));}return s.toString();}
    private static String safe(String s){return s==null?"알 수 없는 오류":s;}
}
