package com.mec.batteryguardian2;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class UpdateActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){ if("com.mec.batteryguardian2.DOWNLOAD_UPDATE".equals(i.getAction())) UpdateManager.downloadPending(c,false); }
}
