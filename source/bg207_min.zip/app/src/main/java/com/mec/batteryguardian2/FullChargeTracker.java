package com.mec.batteryguardian2;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Tracks a discharge cycle only after a real 100% baseline has been seen.
 * This is intentionally lightweight: no extra polling is added, so the tracker
 * itself does not create measurable battery drain.
 */
public final class FullChargeTracker {
    private static final String ACTIVE = "full_track_active";
    private static final String FULL_AT = "full_track_full_at";
    private static final String UNPLUGGED_AT = "full_track_unplugged_at";
    private static final String LAST_PERCENT = "full_track_last_percent";
    private static final String LAST_AT = "full_track_last_at";

    private FullChargeTracker() {}

    public static void observe(Context c, SystemSnapshot s) {
        if (s == null || s.batteryPercent < 0) return;
        SharedPreferences p = AppPrefs.p(c);
        boolean active = p.getBoolean(ACTIVE, false);
        long now = s.capturedAt > 0 ? s.capturedAt : System.currentTimeMillis();

        // A fresh 100% reading becomes the new baseline, even if the cable was
        // unplugged immediately before this sample was taken.
        if (s.batteryPercent >= 100) {
            if (!active) {
                p.edit()
                        .putBoolean(ACTIVE, true)
                        .putLong(FULL_AT, now)
                        .putLong(UNPLUGGED_AT, s.charging ? 0L : now)
                        .putInt(LAST_PERCENT, 100)
                        .putLong(LAST_AT, now)
                        .apply();
            } else if (!s.charging && p.getLong(UNPLUGGED_AT, 0L) == 0L) {
                p.edit().putLong(UNPLUGGED_AT, now).putLong(LAST_AT, now).apply();
            }
            return;
        }

        // Once charging starts again below 100%, the previous full-charge cycle
        // is finished. The next 100% reading starts a clean measurement.
        if (s.charging) {
            if (active) {
                p.edit()
                        .putBoolean(ACTIVE, false)
                        .putLong(UNPLUGGED_AT, 0L)
                        .putInt(LAST_PERCENT, s.batteryPercent)
                        .putLong(LAST_AT, now)
                        .apply();
            }
            return;
        }

        if (!active) return;
        long unplugged = p.getLong(UNPLUGGED_AT, 0L);
        SharedPreferences.Editor e = p.edit();
        if (unplugged == 0L) e.putLong(UNPLUGGED_AT, now);
        e.putInt(LAST_PERCENT, s.batteryPercent).putLong(LAST_AT, now).apply();
    }

    public static String status(Context c, SystemSnapshot s) {
        if (s == null || s.batteryPercent < 0) return "완충 추적: 배터리 확인 중";
        SharedPreferences p = AppPrefs.p(c);
        boolean active = p.getBoolean(ACTIVE, false);

        if (s.charging && s.batteryPercent < 100)
            return "완충 추적: 충전 중 · 100%가 되면 새 기준 시작";

        if (s.batteryPercent >= 100) {
            if (s.charging) return "완충 추적: 100% 기준 기록 완료 · 충전 해제 후 측정";
            return "완충 추적: 100% 기준 측정 시작";
        }

        if (!active) return "완충 추적: 100% 완충 후 자동 시작";

        long start = p.getLong(UNPLUGGED_AT, 0L);
        if (start == 0L) start = p.getLong(FULL_AT, 0L);
        long elapsed = start > 0 ? Math.max(0L, System.currentTimeMillis() - start) : 0L;
        int drop = Math.max(0, 100 - s.batteryPercent);
        return "완충 추적: 100% → " + s.batteryPercent + "% · " + duration(elapsed) + " · " + drop + "% 사용";
    }

    private static String duration(long ms) {
        long minutes = ms / 60_000L;
        long hours = minutes / 60L;
        long mins = minutes % 60L;
        if (hours > 0) return hours + "시간 " + mins + "분";
        return Math.max(0, mins) + "분";
    }
}
