package com.mec.batteryguardian2;

import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.os.Process;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class UsageAccess {
    private UsageAccess() {}
    public static boolean granted(Context c) {
        AppOpsManager a = (AppOpsManager)c.getSystemService(Context.APP_OPS_SERVICE);
        if (a == null) return false;
        int mode = a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }
    public static Map<String,Long> lastUsed(Context c, long lookbackMs) {
        Map<String,Long> out = new HashMap<>();
        UsageStatsManager u = (UsageStatsManager)c.getSystemService(Context.USAGE_STATS_SERVICE);
        if (u == null) return out;
        long now = System.currentTimeMillis();
        List<UsageStats> list = u.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now-lookbackMs, now);
        if (list != null) for (UsageStats s : list) {
            long old = out.containsKey(s.getPackageName()) ? out.get(s.getPackageName()) : 0L;
            out.put(s.getPackageName(), Math.max(old, s.getLastTimeUsed()));
        }
        return out;
    }
}
