package com.mec.batteryguardian2;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;

public final class SystemSnapshot {
    public int batteryPercent;
    public boolean charging;
    public float tempC;
    public long currentMa;
    public long chargeCounterUah;
    public long totalRam;
    public long availRam;
    public int ramUsedPercent;
    public long capturedAt;

    public static SystemSnapshot capture(Context c) {
        SystemSnapshot s = new SystemSnapshot();
        s.capturedAt = System.currentTimeMillis();
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = b != null ? b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
        int scale = b != null ? b.getIntExtra(BatteryManager.EXTRA_SCALE, 100) : 100;
        s.batteryPercent = level >= 0 ? Math.round(level * 100f / Math.max(1, scale)) : -1;
        int status = b != null ? b.getIntExtra(BatteryManager.EXTRA_STATUS, -1) : -1;
        s.charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
        int temp = b != null ? b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) : 0;
        s.tempC = temp / 10f;

        BatteryManager bm = (BatteryManager)c.getSystemService(Context.BATTERY_SERVICE);
        if (bm != null) {
            long ua = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
            if (ua != Long.MIN_VALUE) s.currentMa = Math.abs(ua) / 1000L;
            long cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
            s.chargeCounterUah = cc == Long.MIN_VALUE ? 0L : cc;
        }

        ActivityManager am = (ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);
        if (am != null) {
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            s.totalRam = mi.totalMem;
            s.availRam = mi.availMem;
            long used = Math.max(0, mi.totalMem - mi.availMem);
            s.ramUsedPercent = mi.totalMem > 0 ? (int)Math.round(used * 100.0 / mi.totalMem) : 0;
        }
        return s;
    }

    public static String gb(long bytes) { return String.format(java.util.Locale.KOREA, "%.1f GB", bytes / 1073741824.0); }
}
