package com.mec.batteryguardian2;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ExperimentController {
    // 0=idle, 1=baseline, 2=test, 3=completed-awaiting-user-confirmation
    private static final String P_PHASE="exp_phase", P_START="exp_start", P_CHARGE="exp_charge", P_BASE="exp_base", P_PKGS="exp_pkgs", P_RESULT="exp_result", P_TEST="exp_test";
    private ExperimentController() {}

    public static int phase(Context c) { return AppPrefs.p(c).getInt(P_PHASE,0); }
    public static boolean running(Context c) { int p=phase(c); return p==1 || p==2; }
    public static boolean completed(Context c) { return phase(c)==3; }
    public static String resultMessage(Context c) { return AppPrefs.p(c).getString(P_RESULT,""); }

    public static String status(Context c) {
        int phase = phase(c);
        if (phase == 3) return "테스트 완료 ✓";
        if (phase == 0) return "대기";
        RuleConfig rules = RuleConfig.load(c);
        int total = phase == 1 ? rules.experimentBaselineMinutes : rules.experimentTestMinutes;
        long start = AppPrefs.p(c).getLong(P_START,0);
        long elapsed = Math.max(0,System.currentTimeMillis()-start);
        int remain = (int)Math.max(0, Math.ceil((total*60_000.0-elapsed)/60_000.0));
        return (phase==1 ? "기준 사용량 측정 중" : "절약 설정 시험 중") + " · 약 " + remain + "분 남음";
    }

    public static boolean start(Context c) {
        if (!UsageAccess.granted(c) || !ShizukuBridge.get(c).ready()) return false;
        SharedPreferences p = AppPrefs.p(c);
        if (p.getInt(P_PHASE,0) != 0) return true;
        SystemSnapshot s = SystemSnapshot.capture(c);
        if (s.charging) {
            AppPrefs.setLastMessage(c,"자동 실험은 충전기를 분리한 상태에서 시작해주세요.");
            return false;
        }
        p.edit().putInt(P_PHASE,1).putLong(P_START,System.currentTimeMillis()).putLong(P_CHARGE,s.chargeCounterUah)
                .putString(P_PKGS,"").remove(P_RESULT).remove(P_TEST).apply();
        new GuardianDb(c).addAction("EXPERIMENT","","자동 실험을 시작했습니다. 먼저 평소 배터리 사용량을 측정합니다.","진행 중");
        AppPrefs.setLastMessage(c, "실험 모드: 평소 배터리 사용량을 측정하고 있습니다.");
        return true;
    }

    public static void acknowledge(Context c) {
        AppPrefs.p(c).edit().putInt(P_PHASE,0).remove(P_PKGS).apply();
    }

    public static void tick(Context c) {
        SharedPreferences p = AppPrefs.p(c);
        int phase = p.getInt(P_PHASE,0);
        if (phase == 0 || phase == 3) return;
        RuleConfig rules = RuleConfig.load(c);
        SystemSnapshot s = SystemSnapshot.capture(c);

        if (s.charging) {
            if (phase==2) rollbackPackages(c,p.getString(P_PKGS,""));
            complete(c,"테스트 중단: 충전이 감지되어 결과를 계산하지 않았습니다. 시험 설정은 가능한 범위에서 원상복구했습니다.","중단");
            return;
        }
        if (phase==2 && !ShizukuBridge.get(c).ready()) {
            complete(c,"테스트 중단: Shizuku 연결이 끊겨 실제 제한 상태를 계속 검증할 수 없습니다. Shizuku 연결 후 '자동 제한 모두 원래대로 복구'를 실행할 수 있습니다.","중단");
            return;
        }

        long start = p.getLong(P_START,0);
        long now = System.currentTimeMillis();
        int mins = phase == 1 ? rules.experimentBaselineMinutes : rules.experimentTestMinutes;
        if (now-start < mins*60_000L) return;

        long before = p.getLong(P_CHARGE,0);
        double drainUah = chargeDrain(before, s.chargeCounterUah);
        double perHour = drainUah * 60.0 / Math.max(1.0, mins);

        if (phase == 1) {
            List<AppCandidate> candidates = CandidateFinder.find(c, rules);
            List<String> pkgs = new ArrayList<>();
            int max = Math.min(4, candidates.size());
            for (int i=0;i<max;i++) {
                AppCandidate a = candidates.get(i);
                PowerActions.RestrictResult rr = a.level >= 2 ? PowerActions.strongDetailed(c,a.packageName) : PowerActions.moderateDetailed(c,a.packageName);
                if (rr.success) pkgs.add(a.packageName);
            }
            if (pkgs.isEmpty()) {
                complete(c,"테스트 완료: 실제로 제한 적용이 확인된 안전한 시험 후보가 없어 설정을 변경하지 않았습니다.","변경 없음");
                return;
            }
            SharedPreferences.Editor e = p.edit();
            putDoubleCompat(e,P_BASE,perHour);
            e.putInt(P_PHASE,2).putLong(P_START,now).putLong(P_CHARGE,s.chargeCounterUah).putString(P_PKGS,String.join(",",pkgs)).apply();
            AppPrefs.setLastMessage(c, "실험 모드: 실제 제한 확인된 앱으로 절약 설정을 시험 중입니다. 효과가 없으면 자동으로 되돌립니다.");
        } else {
            double base = getDoubleCompat(p,P_BASE,0.0);
            SharedPreferences.Editor testEditor = p.edit();
            putDoubleCompat(testEditor,P_TEST,perHour);
            testEditor.apply();
            if (base <= 1 || perHour < 0) {
                rollbackPackages(c,p.getString(P_PKGS,""));
                complete(c,"테스트 완료: 배터리 충전량 센서 데이터가 충분하지 않아 개선율을 계산하지 않았습니다. 시험 설정은 원상복구했습니다.","측정 부족");
                return;
            }
            double improvement = (base-perHour)/base*100.0;
            String detail = String.format(Locale.KOREA,"기준 소모 %.1f mAh/h → 제한 적용 후 %.1f mAh/h\n변화율 %.1f%%",base/1000.0,perHour/1000.0,improvement);
            if (improvement >= rules.keepImprovementPercent) {
                AppPrefs.setConfirmedSaving(c,(float)improvement);
                complete(c,"테스트 완료: 실제 소모가 줄어 시험 설정을 유지합니다.\n" + detail,"유지");
            } else {
                rollbackPackages(c,p.getString(P_PKGS,""));
                complete(c,"테스트 완료: 절감 효과가 기준에 미치지 않아 시험 설정을 원상복구했습니다.\n" + detail,"복구");
            }
        }
    }

    private static void rollbackPackages(Context c,String csv) {
        if (csv==null || csv.isEmpty()) return;
        for(String pkg:csv.split(",")) if(!pkg.trim().isEmpty()) PowerActions.rollback(c,pkg.trim());
    }

    private static void complete(Context c,String message,String result) {
        AppPrefs.p(c).edit().putInt(P_PHASE,3).putString(P_RESULT,message).apply();
        AppPrefs.setLastMessage(c,message);
        new GuardianDb(c).addAction("EXPERIMENT","",message,result);
        try { NotificationUtil.alert(c,2308,"자동 실험 테스트 완료",message); } catch(Throwable ignored) {}
    }

    private static double chargeDrain(long before, long after) {
        if (before == 0 || after == 0) return 0.0;
        return Math.max(0.0, before-after);
    }
    private static void putDoubleCompat(SharedPreferences.Editor e,String k,double v) { e.putLong(k,Double.doubleToRawLongBits(v)); }
    private static double getDoubleCompat(SharedPreferences p,String k,double d) {
        long bits=p.getLong(k,Double.doubleToRawLongBits(d)); return Double.longBitsToDouble(bits);
    }
}
