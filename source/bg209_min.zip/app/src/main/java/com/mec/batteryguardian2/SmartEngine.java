package com.mec.batteryguardian2;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class SmartEngine {
    public static final class Result {
        public String headline;
        public String explanation;
        public int moderateCount;
        public int strongCount;
        public int candidateCount;
        public boolean acted;
        public double predictedSavingPercent;
        public List<String> changedPackages = new ArrayList<>();
        public List<String> moderateNames = new ArrayList<>();
        public List<String> strongNames = new ArrayList<>();
        public List<String> changedNames = new ArrayList<>();
        public List<String> failedNames = new ArrayList<>();
        public List<String> failedDetails = new ArrayList<>();
    }

    private SmartEngine() {}

    public static Result analyze(Context c, boolean apply) {
        RuleConfig rules = RuleConfig.load(c);
        SystemSnapshot s = SystemSnapshot.capture(c);
        List<AppCandidate> candidates = CandidateFinder.find(c, rules);
        Result r = new Result();
        r.candidateCount = candidates.size();

        if (!UsageAccess.granted(c)) {
            r.headline = "사용 기록 권한이 필요합니다";
            r.explanation = "어떤 앱을 자주 쓰고 안 쓰는지 알아야 중요한 앱은 보호하고, 필요 없는 앱만 제한할 수 있습니다.";
            return r;
        }
        if (!ShizukuBridge.get(c).ready()) {
            r.headline = "Shizuku 연결이 필요합니다";
            r.explanation = "분석은 가능하지만 실제 백그라운드 제한을 적용하고 다시 검증하려면 Shizuku 연결이 필요합니다.";
            return r;
        }

        int moderateLimit = rules.maxModerateAppsPerRun;
        int strongLimit = rules.maxStrongAppsPerRun;
        for (AppCandidate a : candidates) {
            if (a.level >= 2 && r.strongCount < strongLimit) {
                r.strongCount++;
                r.strongNames.add(a.label);
                if (apply) {
                    PowerActions.RestrictResult rr = PowerActions.strongDetailed(c,a.packageName);
                    if (rr.success) {
                        r.changedPackages.add(a.packageName); r.changedNames.add(a.label); r.acted=true;
                    } else {
                        r.failedNames.add(a.label); r.failedDetails.add(a.label + ": " + oneLine(rr.detail));
                    }
                }
            } else if (a.level == 1 && r.moderateCount < moderateLimit) {
                r.moderateCount++;
                r.moderateNames.add(a.label);
                if (apply) {
                    PowerActions.RestrictResult rr = PowerActions.moderateDetailed(c,a.packageName);
                    if (rr.success) {
                        r.changedPackages.add(a.packageName); r.changedNames.add(a.label); r.acted=true;
                    } else {
                        r.failedNames.add(a.label); r.failedDetails.add(a.label + ": " + oneLine(rr.detail));
                    }
                }
            }
            if (r.strongCount >= strongLimit && r.moderateCount >= moderateLimit) break;
        }

        double base = s.currentMa > 0 ? s.currentMa : 800.0;
        double estimatedMa = r.strongCount * 25.0 + r.moderateCount * 10.0;
        r.predictedSavingPercent = Math.min(25.0, estimatedMa / Math.max(250.0, base) * 100.0);

        int managed = PowerActions.managedCount(c);
        if (candidates.isEmpty()) {
            r.headline = "새로 제한할 앱은 없습니다";
            if (managed > 0) {
                r.explanation = "현재 실제 제한 확인된 앱 " + managed + "개의 설정을 유지하고 있습니다.\n"
                        + "같은 앱을 반복 제한하지 않고, 새롭게 오래 사용하지 않은 앱이 생겼을 때만 추가 적용합니다.\n"
                        + "제한했던 앱을 다시 사용하면 자동으로 원래 상태로 복구합니다.";
            } else if (s.currentMa > rules.veryHighDrainMa && !s.charging) {
                r.explanation = "현재 전력 사용은 높은 편이지만, 오래 방치된 앱이 원인은 아닌 것으로 보입니다. 지금 사용 중인 화면이나 앱의 영향이 더 큽니다.";
            } else {
                r.explanation = "자주 쓰는 앱과 보호 앱을 제외하고 확인했지만 지금 새로 제한할 만한 앱은 없습니다.";
            }
        } else if (apply) {
            StringBuilder b = new StringBuilder();
            if (r.acted) {
                r.headline = "백그라운드 제한 적용을 확인했습니다";
                b.append("이번에 실제 제한 상태까지 확인된 앱 ").append(r.changedNames.size()).append("개: ").append(joinNames(r.changedNames));
                b.append("\n→ 명령 실행 뒤 대기 버킷/AppOps를 다시 읽어 실제 적용 여부를 확인했습니다.");
            } else {
                r.headline = "백그라운드 제한 적용 실패";
                b.append("후보 앱은 찾았지만 실제 제한 상태가 확인된 앱은 없습니다.");
            }
            if (!r.failedDetails.isEmpty()) {
                b.append("\n\n실패/확인 필요 ").append(r.failedDetails.size()).append("개");
                int max=Math.min(5,r.failedDetails.size());
                for(int i=0;i<max;i++) b.append("\n• ").append(r.failedDetails.get(i));
                if(r.failedDetails.size()>max) b.append("\n• 외 ").append(r.failedDetails.size()-max).append("개");
                b.append("\n권한 거부가 나오면 Shizuku shell 범위에서 대체 명령을 자동 재시도하고, 그래도 막히면 이유를 그대로 기록합니다.");
            }
            b.append("\n\n카카오톡·전화·시스템 앱과 보호 앱은 제외합니다. 이미 실제 제한 확인된 앱은 반복 적용하지 않습니다.");
            r.explanation=b.toString();
        } else {
            r.headline = "새로 제한할 앱을 찾았습니다";
            StringBuilder b = new StringBuilder();
            b.append("최근 거의 사용하지 않은 새 앱 ").append(candidates.size()).append("개를 찾았습니다.");
            if (!r.strongNames.isEmpty()) b.append("\n강한 제한 후보: ").append(joinNames(r.strongNames));
            if (!r.moderateNames.isEmpty()) b.append("\n일반 제한 후보: ").append(joinNames(r.moderateNames));
            b.append("\n중요 앱과 이미 제한 중인 앱은 제외했습니다.");
            r.explanation = b.toString();
        }

        if (s.tempC >= rules.highTempC) r.explanation += "\n현재 온도도 높은 편이라 열이 내려가면 전력 효율이 더 좋아질 수 있습니다.";
        return r;
    }

    private static String oneLine(String s) {
        if(s==null) return "원인 확인 불가";
        String v=s.replace('\n',' ').replaceAll("\\s+"," ").trim();
        return v.length()>150?v.substring(0,150)+"…":v;
    }
    private static String joinNames(List<String> names) {
        if (names.isEmpty()) return "없음";
        int max = Math.min(8, names.size());
        StringBuilder b = new StringBuilder();
        for (int i=0;i<max;i++) { if (i>0) b.append(", "); b.append(names.get(i)); }
        if (names.size()>max) b.append(" 외 ").append(names.size()-max).append("개");
        return b.toString();
    }
    public static String predictedText(Result r) {
        if (r.candidateCount == 0) return "가상 계산: 새로 추가할 절감 후보 없음";
        return String.format(Locale.KOREA, "가상 계산: 새 후보 기준 약 %.0f%% 정도의 불필요 소모 감소 가능성", r.predictedSavingPercent);
    }
}
