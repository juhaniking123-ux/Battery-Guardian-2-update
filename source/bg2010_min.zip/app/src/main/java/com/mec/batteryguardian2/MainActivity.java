package com.mec.batteryguardian2;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView batteryValue, ramValue, tempValue, currentValue, insight, shizukuState, usageState, savingValue, learningValue, experimentValue, fullChargeValue, anomalyValue, actionLog;
    private Switch autoSwitch;
    private Button experimentButton;
    private ShizukuBridge shizuku;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private boolean experimentDialogShowing = false;
    private final Runnable uiRefresh = new Runnable() {
        @Override public void run() {
            refreshAll();
            uiHandler.postDelayed(this, 15000L);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        NotificationUtil.ensureChannels(this);
        shizuku = ShizukuBridge.get(this);
        shizuku.setCallback(() -> runOnUiThread(this::refreshAll));
        shizuku.ensureBound();
        setContentView(buildUi());
        askNotificationPermission();
        seedProtectedDefaults();
        refreshAll();
        // v2.0.10: repair notification-critical apps if an older Guardian build restricted them.
        scheduleCriticalNotificationRepair();
        UpdateManager.checkInBackground(this, false);
    }

    @Override protected void onResume() {
        super.onResume();
        shizuku.ensureBound();
        refreshAll();
        uiHandler.removeCallbacks(uiRefresh);
        uiHandler.postDelayed(uiRefresh, 15000L);
    }

    @Override protected void onPause() {
        uiHandler.removeCallbacks(uiRefresh);
        super.onPause();
    }

    @Override protected void onDestroy() { uiHandler.removeCallbacks(uiRefresh); worker.shutdownNow(); super.onDestroy(); }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(Color.rgb(246,248,252));
        LinearLayout root = col();
        root.setPadding(dp(18), dp(24), dp(18), dp(36));
        sv.addView(root);

        // Android 15/16/17 edge-to-edge can place the first line under the status bar.
        // Apply the real system-bar inset so the title stays fully visible on Galaxy devices.
        sv.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            root.setPadding(dp(18), top + dp(18), dp(18), bottom + dp(36));
            return insets;
        });

        TextView title = text("Battery Guardian 2", 28, true, Color.rgb(23,32,51));
        title.setIncludeFontPadding(true);
        title.setPadding(0, dp(6), 0, dp(2));
        root.addView(title);
        TextView sub = text("Galaxy S26 Ultra · 자동 분석 → 해결 → 재확인", 14, false, Color.rgb(107,114,128));
        sub.setPadding(0,dp(2),0,dp(12)); root.addView(sub);

        LinearLayout stats1 = row();
        batteryValue = statCard(stats1,"배터리","--");
        ramValue = statCard(stats1,"RAM","--");
        root.addView(stats1);
        LinearLayout stats2 = row();
        tempValue = statCard(stats2,"온도","--");
        currentValue = statCard(stats2,"현재 소모","--");
        root.addView(stats2);

        LinearLayout autoCard = card();
        LinearLayout autoRow = row();
        LinearLayout labels = col(); labels.setLayoutParams(new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        labels.addView(text("스마트 자동 관리",18,true,Color.rgb(23,32,51)));
        labels.addView(text("최근 사용하지 않은 앱만 골라 백그라운드 활동을 줄이고, 다시 쓰면 자동 복구합니다.",13,false,Color.rgb(107,114,128)));
        autoRow.addView(labels);
        autoSwitch = new Switch(this); autoSwitch.setChecked(AppPrefs.autoManage(this)); autoRow.addView(autoSwitch);
        autoCard.addView(autoRow);
        autoSwitch.setOnCheckedChangeListener((v,checked)->{
            AppPrefs.setAutoManage(this,checked);
            if (checked) {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) askNotificationPermission();
                try { MonitorService.start(this); } catch (Exception e) { toastDialog("자동 관리 시작 실패",e.getMessage()); }
            } else MonitorService.stop(this);
        });
        root.addView(autoCard);

        LinearLayout explainCard = card();
        explainCard.addView(text("지금 상태를 쉽게 설명하면",17,true,Color.rgb(23,32,51)));
        insight = text("확인 중...",15,false,Color.rgb(45,55,72)); insight.setPadding(0,dp(8),0,0); explainCard.addView(insight);
        savingValue = text("실제 절감 효과: 학습 중",14,true,Color.rgb(15,157,88)); savingValue.setPadding(0,dp(10),0,0); explainCard.addView(savingValue);
        learningValue = text("학습 진행: 계산 중...",13,true,Color.rgb(63,81,181)); learningValue.setPadding(0,dp(7),0,0); explainCard.addView(learningValue);
        experimentValue = text("실험 모드: 대기",13,false,Color.rgb(107,114,128)); experimentValue.setPadding(0,dp(5),0,0); explainCard.addView(experimentValue);
        fullChargeValue = text("완충 추적: 100% 충전 대기",13,false,Color.rgb(107,114,128)); fullChargeValue.setPadding(0,dp(5),0,0); explainCard.addView(fullChargeValue);
        anomalyValue = text("변화 감지: 정상 감시 중",13,false,Color.rgb(107,114,128)); anomalyValue.setPadding(0,dp(5),0,0); explainCard.addView(anomalyValue);
        root.addView(explainCard);

        Button optimize = primaryButton("⚡ 스마트 최적화 한 번에 실행");
        optimize.setOnClickListener(v -> runSmartOptimize()); root.addView(optimize);
        Button background = secondaryButton("🔒 백그라운드 제한 상세 실행");
        background.setOnClickListener(v -> runBackgroundRestrict()); root.addView(background);
        Button ram = secondaryButton("🚀 스마트 RAM 부스트");
        ram.setOnClickListener(v -> runRamBoost()); root.addView(ram);
        experimentButton = secondaryButton("🧪 자동 실험 모드 시작");
        experimentButton.setOnClickListener(v -> startExperiment()); root.addView(experimentButton);

        LinearLayout perm = card();
        perm.addView(text("필수 연결",17,true,Color.rgb(23,32,51)));
        usageState = text("사용 기록: 확인 중",14,false,Color.rgb(107,114,128)); perm.addView(usageState);
        shizukuState = text("Shizuku: 확인 중",14,false,Color.rgb(107,114,128)); perm.addView(shizukuState);
        Button usage = smallButton("사용 기록 권한 열기");
        usage.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
        perm.addView(usage);
        Button sh = smallButton("Shizuku 연결 / 권한");
        sh.setOnClickListener(v -> handleShizuku()); perm.addView(sh);
        root.addView(perm);

        LinearLayout logs = card();
        logs.addView(text("최근 자동 해결 / 변화 감지",17,true,Color.rgb(23,32,51)));
        actionLog = text("아직 기록이 없습니다.",13,false,Color.rgb(107,114,128)); actionLog.setPadding(0,dp(8),0,0); logs.addView(actionLog);
        root.addView(logs);

        LinearLayout bottom = row();
        Button protect = smallButton("보호 앱"); protect.setOnClickListener(v -> startActivity(new Intent(this, ProtectedAppsActivity.class))); bottom.addView(protect,new LinearLayout.LayoutParams(0,dp(46),1));
        Button settings = smallButton("설정 / 업데이트"); settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class))); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0,dp(46),1); bp.setMargins(dp(8),0,0,0); bottom.addView(settings,bp);
        root.addView(bottom);

        TextView version = text("Battery Guardian 2  ·  v2.0.10  ·  Rule Engine 2",12,false,Color.rgb(130,138,150));
        version.setGravity(Gravity.CENTER); version.setPadding(0,dp(22),0,0); root.addView(version);
        return sv;
    }

    private void refreshAll() {
        SystemSnapshot s = SystemSnapshot.capture(this);
        FullChargeTracker.observe(this, s);
        AnomalyDetector.observe(this, s);
        batteryValue.setText(s.batteryPercent < 0 ? "--" : s.batteryPercent + "%");
        ramValue.setText(s.ramUsedPercent + "%\n" + SystemSnapshot.gb(s.totalRam-s.availRam) + " / " + SystemSnapshot.gb(s.totalRam));
        tempValue.setText(String.format(java.util.Locale.KOREA,"%.1f℃",s.tempC));
        currentValue.setText(s.charging ? "충전 중" : (s.currentMa > 0 ? s.currentMa + " mA" : "측정 대기"));
        usageState.setText("사용 기록: " + (UsageAccess.granted(this)?"연결됨 ✓":"권한 필요"));
        String sz = !shizuku.binderAlive()?"Shizuku가 실행되지 않음":!shizuku.granted()?"권한 필요":shizuku.ready()?"연결됨 ✓ (UID "+shizuku.remoteUid()+")":"연결 중";
        shizukuState.setText("Shizuku: " + sz);
        float save = AppPrefs.confirmedSaving(this);
        savingValue.setText(save >= 0 ? String.format(java.util.Locale.KOREA,"실제 절감 효과: 최근 실험에서 약 %.1f%% 개선",save) : "실제 절감 효과: 아직 학습 중");
        learningValue.setText(learningStatusText());
        experimentValue.setText("실험 모드: " + ExperimentController.status(this));
        if (experimentButton != null) {
            if (ExperimentController.completed(this)) experimentButton.setText("🧪 실험 결과 확인");
            else if (ExperimentController.running(this)) experimentButton.setText("🧪 자동 실험 진행 중");
            else experimentButton.setText("🧪 자동 실험 모드 시작");
        }
        if (ExperimentController.completed(this) && !experimentDialogShowing) {
            experimentDialogShowing = true;
            uiHandler.postDelayed(this::showExperimentResult, 250L);
        }
        fullChargeValue.setText(FullChargeTracker.status(this, s));
        String anomaly = AnomalyDetector.lastStatus(this);
        anomalyValue.setText(anomaly.startsWith("아직") ? "변화 감지: 정상 감시 중" : "변화 감지: " + anomaly);
        String last = AppPrefs.lastMessage(this);
        if (!last.isEmpty()) {
            if (last.contains("개의 뒤쪽 활동을 줄였습니다")) {
                int managed = PowerActions.managedCount(this);
                insight.setText("현재 백그라운드 제한 중인 앱 " + managed + "개의 설정을 유지하고 있습니다.\n같은 앱을 반복 제한하지 않고, 새 후보가 생길 때만 추가 적용합니다. 다시 사용한 앱은 자동 복구합니다.");
            } else insight.setText(last);
        }
        List<String> acts = new GuardianDb(this).recentActions(5);
        actionLog.setText(acts.isEmpty()?"아직 자동 해결 기록이 없습니다.":String.join("\n",acts));
    }

    private String learningStatusText() {
        final long DAY = 24L * 60L * 60L * 1000L;
        final long TOTAL = 7L * DAY;
        long now = System.currentTimeMillis();
        long start = now;
        try {
            android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            if (pi.firstInstallTime > 0L) start = pi.firstInstallTime;
        } catch (Exception ignored) {}

        long elapsed = Math.max(0L, now - start);
        int progress = (int)Math.min(100L, (elapsed * 100L) / TOTAL);
        if (elapsed >= TOTAL) {
            return "학습 진행: 7일 / 7일 · 100% 완료 ✓\n현재 상태: 지속 학습 중 · 사용 패턴 변화 반영 중";
        }

        int day = Math.min(7, (int)(elapsed / DAY) + 1);
        long remainMs = Math.max(0L, TOTAL - elapsed);
        long remainDays = Math.max(1L, (remainMs + DAY - 1L) / DAY);
        int remainPct = Math.max(0, 100 - progress);
        return "학습 진행: " + day + "일차 / 7일 · " + progress + "% 진행 중\n"
                + "남은 학습: 약 " + remainDays + "일 · " + remainPct + "% 남음";
    }


    private void scheduleCriticalNotificationRepair() {
        worker.submit(() -> {
            for (int i=0; i<6; i++) {
                try {
                    shizuku.ensureBound();
                    if (shizuku.ready()) {
                        int repaired = PowerActions.repairCriticalNotificationApps(this);
                        if (repaired > 0) {
                            String msg = "카카오톡 등 알림 필수 앱의 백그라운드 제한을 자동 복구했습니다. 화면이 꺼진 상태에서도 알림이 오도록 보호합니다.";
                            AppPrefs.setLastMessage(this, msg);
                            runOnUiThread(() -> { insight.setText(msg); refreshAll(); });
                        }
                        return;
                    }
                    Thread.sleep(1200L);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                } catch (Throwable ignored) {}
            }
        });
    }

    private void runSmartOptimize() {
        if (!UsageAccess.granted(this)) { explainNeedUsage(); return; }
        if (!shizuku.granted()) { handleShizuku(); return; }
        shizuku.ensureBound();
        insight.setText("현재 상태를 확인하고, 중요한 앱은 제외한 뒤 실제로 줄일 수 있는 부분을 찾고 있습니다...");
        worker.submit(() -> {
            try { Thread.sleep(350); } catch (InterruptedException ignored) {}
            SmartEngine.Result preview = SmartEngine.analyze(this,false);
            SmartEngine.Result result = SmartEngine.analyze(this,true);
            String msg = result.explanation + "\n\n" + SmartEngine.predictedText(preview);
            AppPrefs.setLastMessage(this,msg);
            runOnUiThread(() -> { insight.setText(msg); refreshAll(); });
        });
    }


    private void runBackgroundRestrict() {
        if (!UsageAccess.granted(this)) { explainNeedUsage(); return; }
        if (!shizuku.granted()) { handleShizuku(); return; }
        shizuku.ensureBound();
        insight.setText("새롭게 오래 사용하지 않은 앱만 확인하고 있습니다. 이미 제한 중인 앱은 다시 건드리지 않습니다...");
        worker.submit(() -> {
            SmartEngine.Result result = SmartEngine.analyze(this,true);
            String msg = result.explanation;
            AppPrefs.setLastMessage(this,msg);
            runOnUiThread(() -> { insight.setText(msg); refreshAll(); });
        });
    }

    private void runRamBoost() {
        if (!UsageAccess.granted(this)) { explainNeedUsage(); return; }
        if (!shizuku.granted()) { handleShizuku(); return; }
        shizuku.ensureBound();
        SystemSnapshot before = SystemSnapshot.capture(this);
        insight.setText("RAM을 무조건 비우지 않고, 최근 사용하지 않은 앱만 골라 정리하고 있습니다...");
        worker.submit(() -> {
            RuleConfig rules = RuleConfig.load(this);
            List<AppCandidate> list = CandidateFinder.forRamBoost(this,rules);
            int killed=0;
            for (AppCandidate a:list) {
                if (killed>=12) break;
                if (PowerActions.killBackground(this,a.packageName)) killed++;
            }
            try { Thread.sleep(1800); } catch (InterruptedException ignored) {}
            SystemSnapshot after = SystemSnapshot.capture(this);
            long gained = Math.max(0, after.availRam-before.availRam);
            String msg = "RAM 정리 전 " + before.ramUsedPercent + "% → 정리 후 " + after.ramUsedPercent + "%\n" +
                    "확보된 RAM 약 " + SystemSnapshot.gb(gained) + " · 최근 쓰던 앱과 보호 앱은 유지했습니다.";
            if (killed==0) msg = "지금은 억지로 RAM을 비우는 것보다 그대로 두는 편이 낫습니다. 정리할 만한 오래된 앱이 거의 없습니다.";
            new GuardianDb(this).addAction("RAM","",msg,killed+"개 정리"); AppPrefs.setLastMessage(this,msg);
            String finalMsg=msg; runOnUiThread(() -> { insight.setText(finalMsg); refreshAll(); });
        });
    }

    private void startExperiment() {
        if (ExperimentController.completed(this)) { showExperimentResult(); return; }
        if (ExperimentController.running(this)) {
            toastDialog("자동 실험 진행 중", ExperimentController.status(this) + "\n\n완료되면 '테스트 완료 ✓' 상태와 결과가 표시됩니다.");
            return;
        }
        if (!UsageAccess.granted(this)) { explainNeedUsage(); return; }
        if (!shizuku.granted()) { handleShizuku(); return; }
        shizuku.ensureBound();
        SystemSnapshot now = SystemSnapshot.capture(this);
        if (now.charging) { toastDialog("실험 모드","충전기를 분리한 뒤 시작해주세요. 충전 중에는 배터리 절감 효과를 비교할 수 없습니다."); return; }
        if (!AppPrefs.autoManage(this)) { AppPrefs.setAutoManage(this,true); autoSwitch.setChecked(true); }
        boolean ok = ExperimentController.start(this);
        if (ok) {
            MonitorService.start(this);
            insight.setText("실험을 시작했습니다.\n1단계: 평소 사용량 측정 → 2단계: 실제 제한 확인된 앱으로 절약 시험 → 완료 후 결과 표시\n효과가 없으면 시험 설정은 자동 원상복구합니다.");
            refreshAll();
        } else toastDialog("실험 모드","사용 기록 권한, Shizuku 연결, 충전 상태를 확인해주세요.");
    }

    private void showExperimentResult() {
        if (!ExperimentController.completed(this)) { experimentDialogShowing=false; return; }
        String msg = ExperimentController.resultMessage(this);
        if (msg == null || msg.isEmpty()) msg = "자동 실험이 완료되었습니다.";
        new AlertDialog.Builder(this)
                .setTitle("자동 실험 테스트 완료")
                .setMessage(msg + "\n\n확인을 누르면 실험 모드는 대기 상태로 돌아갑니다.")
                .setCancelable(false)
                .setPositiveButton("확인",(d,w)->{
                    ExperimentController.acknowledge(this);
                    experimentDialogShowing=false;
                    refreshAll();
                }).show();
    }

    private void explainNeedUsage() {
        new AlertDialog.Builder(this).setTitle("사용 기록 권한이 필요합니다")
                .setMessage("어떤 앱을 자주 쓰는지 알아야 카카오톡 같은 중요한 앱은 건드리지 않고, 안 쓰는 앱만 골라서 제한할 수 있습니다.")
                .setPositiveButton("권한 설정 열기",(d,w)->startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)))
                .setNegativeButton("취소",null).show();
    }

    private void handleShizuku() {
        if (!shizuku.binderAlive()) {
            try {
                Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch != null) startActivity(launch); else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=moe.shizuku.privileged.api")));
            } catch (Exception e) { toastDialog("Shizuku","Shizuku를 먼저 실행해주세요."); }
        } else if (!shizuku.granted()) shizuku.requestPermission();
        else { shizuku.ensureBound(); refreshAll(); }
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4001);
    }
    private void seedProtectedDefaults() {
        if (AppPrefs.p(this).getBoolean("protected_seeded",false)) return;
        AppPrefs.setProtectedApps(this,CandidateFinder.defaultProtected(this));
        AppPrefs.p(this).edit().putBoolean("protected_seeded",true).apply();
    }
    private void toastDialog(String title,String msg) { new AlertDialog.Builder(this).setTitle(title).setMessage(msg==null?"":msg).setPositiveButton("확인",null).show(); }

    private LinearLayout col() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout card() { LinearLayout l=col(); l.setPadding(dp(16),dp(15),dp(16),dp(15)); GradientDrawable g=new GradientDrawable(); g.setColor(Color.WHITE); g.setCornerRadius(dp(18)); l.setBackground(g); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT); p.setMargins(0,0,0,dp(12)); l.setLayoutParams(p); l.setElevation(dp(1)); return l; }
    private TextView text(String s,int sp,boolean bold,int color) { TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color); v.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); v.setLineSpacing(0,1.12f); return v; }
    private TextView statCard(LinearLayout parent,String label,String value) { LinearLayout c=card(); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1); p.setMargins(0,0,dp(6),dp(10)); c.setLayoutParams(p); c.addView(text(label,13,false,Color.rgb(107,114,128))); TextView v=text(value,22,true,Color.rgb(23,32,51)); v.setPadding(0,dp(5),0,0); c.addView(v); parent.addView(c); return v; }
    private Button primaryButton(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setTextColor(Color.WHITE); b.setAllCaps(false); GradientDrawable g=new GradientDrawable(); g.setColor(Color.rgb(37,99,235)); g.setCornerRadius(dp(16)); b.setBackground(g); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(58)); p.setMargins(0,0,0,dp(10)); b.setLayoutParams(p); return b; }
    private Button secondaryButton(String s) { Button b=primaryButton(s); b.setTextColor(Color.rgb(29,78,216)); GradientDrawable g=new GradientDrawable(); g.setColor(Color.WHITE); g.setStroke(dp(1),Color.rgb(210,220,238)); g.setCornerRadius(dp(16)); b.setBackground(g); return b; }
    private Button smallButton(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(13); b.setAllCaps(false); b.setTextColor(Color.rgb(29,78,216)); return b; }
    private int dp(int v) { return Math.round(v*getResources().getDisplayMetrics().density); }
}
