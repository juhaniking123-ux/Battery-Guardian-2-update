package com.mec.batteryguardian2;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;

public final class PowerActions {
    private PowerActions() {}
    private static String key(String type, String pkg) { return "rb_" + type + "_" + pkg; }

    public static final class RestrictResult {
        public boolean success;
        public String detail = "";
        public String bucket = "";
        public String runAny = "";
        public String runIn = "";
        public String wake = "";
    }

    public static boolean moderate(Context c, String pkg) { return moderateDetailed(c,pkg).success; }
    public static boolean strong(Context c, String pkg) { return strongDetailed(c,pkg).success; }

    public static RestrictResult moderateDetailed(Context c, String pkg) {
        return applyRestriction(c,pkg,false);
    }

    public static RestrictResult strongDetailed(Context c, String pkg) {
        return applyRestriction(c,pkg,true);
    }

    private static RestrictResult applyRestriction(Context c, String pkg, boolean strong) {
        RestrictResult out = new RestrictResult();
        String name = appLabel(c,pkg);
        if (!ShizukuBridge.safePackage(pkg)) {
            out.detail = "패키지 이름을 안전하게 확인할 수 없어 중단했습니다.";
            logRestriction(c,strong,pkg,name,out);
            return out;
        }
        ShizukuBridge b = ShizukuBridge.get(c);
        if (!b.ready()) {
            out.detail = "Shizuku 서비스가 연결되지 않아 제한 명령을 실행하지 못했습니다.";
            logRestriction(c,strong,pkg,name,out);
            return out;
        }

        saveBefore(c,pkg);
        String targetBucket = strong ? "restricted" : "rare";
        StringBuilder raw = new StringBuilder();

        String bucketSet = b.exec("am set-standby-bucket " + pkg + " " + targetBucket);
        raw.append(bucketSet).append('\n');
        if (!ok(bucketSet)) {
            // Some Samsung/Android builds only accept the explicit current-user form.
            String retry = b.exec("am set-standby-bucket --user current " + pkg + " " + targetBucket);
            raw.append(retry).append('\n');
        }

        // AppOps is the actual background-execution gate. Apply it one command at a time so
        // a single OEM-rejected op does not hide the result of the other operations.
        String runAnySet = b.exec("cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND ignore");
        raw.append(runAnySet).append('\n');
        if (strong) {
            String runInSet = b.exec("cmd appops set " + pkg + " RUN_IN_BACKGROUND ignore");
            String wakeSet = b.exec("cmd appops set " + pkg + " WAKE_LOCK ignore");
            raw.append(runInSet).append('\n').append(wakeSet).append('\n');
        }

        // Verify the *real* post-state. We do not call an operation successful merely because
        // the shell command returned EXIT=0.
        String bucketOut = b.exec("am get-standby-bucket " + pkg);
        String runAnyOut = b.exec("cmd appops get " + pkg + " RUN_ANY_IN_BACKGROUND");
        String runInOut = strong ? b.exec("cmd appops get " + pkg + " RUN_IN_BACKGROUND") : "";
        String wakeOut = strong ? b.exec("cmd appops get " + pkg + " WAKE_LOCK") : "";
        out.bucket = parseBucket(bucketOut);
        out.runAny = parseAppOp(runAnyOut);
        out.runIn = strong ? parseAppOp(runInOut) : "-";
        out.wake = strong ? parseAppOp(wakeOut) : "-";

        boolean bucketOk = strong ? "restricted".equals(out.bucket) : ("rare".equals(out.bucket) || "restricted".equals(out.bucket));
        boolean runAnyOk = "ignore".equals(out.runAny);
        boolean runInOk = !strong || "ignore".equals(out.runIn);
        boolean wakeOk = !strong || "ignore".equals(out.wake);
        out.success = bucketOk && runAnyOk && runInOk && wakeOk;

        if (out.success) {
            markManaged(c,pkg);
            out.detail = strong
                    ? "실제 제한 확인 완료 · 대기 버킷 restricted · 백그라운드 실행/Wake Lock 제한 확인"
                    : "실제 제한 확인 완료 · 대기 버킷 " + out.bucket + " · 백그라운드 실행 제한 확인";
        } else {
            out.detail = failureReason(raw.toString(), bucketOut + "\n" + runAnyOut + "\n" + runInOut + "\n" + wakeOut)
                    + "\n확인값: bucket=" + out.bucket + ", RUN_ANY=" + out.runAny
                    + (strong ? ", RUN_IN=" + out.runIn + ", WAKE_LOCK=" + out.wake : "");
        }
        logRestriction(c,strong,pkg,name,out);
        return out;
    }

    private static void logRestriction(Context c, boolean strong, String pkg, String name, RestrictResult r) {
        String type = strong ? "백그라운드 강함" : "백그라운드 일반";
        String msg = name + ": " + r.detail;
        new GuardianDb(c).addAction(type,pkg,msg,r.success?"실제 적용 확인":"실패");
    }

    private static String failureReason(String applyOut, String verifyOut) {
        String all = ((applyOut==null?"":applyOut) + "\n" + (verifyOut==null?"":verifyOut)).toLowerCase(Locale.ROOT);
        if (all.contains("permission denial") || all.contains("permission denied") || all.contains("not allowed") || all.contains("securityexception")) {
            return "권한 거부 · Shizuku shell 권한으로 대체 명령까지 재시도했지만 시스템이 차단했습니다.";
        }
        if (all.contains("unknown operation") || all.contains("unknown command") || all.contains("not found") || all.contains("invalid")) {
            return "이 기기/Android 버전에서 일부 제한 명령이 지원되지 않습니다.";
        }
        if (all.contains("shizuku service not ready") || all.contains("binder") || all.contains("dead object")) {
            return "Shizuku 연결이 끊겨 실제 제한 상태를 확인하지 못했습니다.";
        }
        if (all.contains("timeout")) return "제한 명령 응답 시간이 초과되었습니다.";
        return "명령은 실행했지만 실제 제한 상태가 목표값으로 바뀌지 않았습니다.";
    }

    public static boolean killBackground(Context c, String pkg) {
        if (!ShizukuBridge.safePackage(pkg)) return false;
        ShizukuBridge b = ShizukuBridge.get(c); if (!b.ready()) return false;
        String r = b.exec("am kill --user current " + pkg);
        return ok(r);
    }

    public static boolean rollback(Context c, String pkg) {
        if (!ShizukuBridge.safePackage(pkg)) return false;
        ShizukuBridge b = ShizukuBridge.get(c); if (!b.ready()) return false;
        SharedPreferences p = AppPrefs.p(c);
        String bucket = p.getString(key("bucket",pkg), "active");
        String appop = p.getString(key("appop",pkg), "allow");
        String runin = p.getString(key("runin",pkg), "allow");
        String wake = p.getString(key("wake",pkg), "allow");
        if (!bucket.matches("active|working_set|frequent|rare|restricted")) bucket = "active";
        if (!appop.matches("allow|ignore|default|foreground")) appop = "allow";
        if (!runin.matches("allow|ignore|default|foreground")) runin = "allow";
        if (!wake.matches("allow|ignore|default|foreground")) wake = "allow";
        String r1 = b.exec("am set-standby-bucket " + pkg + " " + bucket);
        String r2 = b.exec("cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND " + appop);
        String r3 = b.exec("cmd appops set " + pkg + " RUN_IN_BACKGROUND " + runin);
        String r4 = b.exec("cmd appops set " + pkg + " WAKE_LOCK " + wake);
        String bucketAfter = parseBucket(b.exec("am get-standby-bucket " + pkg));
        String appAfter = parseAppOp(b.exec("cmd appops get " + pkg + " RUN_ANY_IN_BACKGROUND"));
        boolean success = ok(r1) && ok(r2) && (bucketAfter.equals(bucket) || (bucket.equals("active") && !bucketAfter.isEmpty())) && appAfter.equals(appop);
        if(success) {
            unmarkManaged(c,pkg);
            p.edit().remove(key("bucket",pkg)).remove(key("appop",pkg)).remove(key("runin",pkg)).remove(key("wake",pkg)).apply();
        }
        new GuardianDb(c).addAction("ROLLBACK", pkg, "시험/자동 제한 설정을 원래대로 돌렸습니다.", success?"복구 확인":"복구 실패");
        return success;
    }

    private static void saveBefore(Context c, String pkg) {
        SharedPreferences p = AppPrefs.p(c);
        if (p.contains(key("bucket",pkg))) return;
        ShizukuBridge b = ShizukuBridge.get(c);
        String bucketOut = b.exec("am get-standby-bucket " + pkg);
        String appOut = b.exec("cmd appops get " + pkg + " RUN_ANY_IN_BACKGROUND");
        String runInOut = b.exec("cmd appops get " + pkg + " RUN_IN_BACKGROUND");
        String wakeOut = b.exec("cmd appops get " + pkg + " WAKE_LOCK");
        p.edit()
                .putString(key("bucket",pkg), parseBucket(bucketOut))
                .putString(key("appop",pkg), parseAppOp(appOut))
                .putString(key("runin",pkg), parseAppOp(runInOut))
                .putString(key("wake",pkg), parseAppOp(wakeOut)).apply();
    }

    private static String parseBucket(String s) {
        if (s == null) return "active";
        String low = s.toLowerCase(Locale.ROOT);
        if (low.contains("restricted") || low.matches("(?s).*\\b45\\b.*")) return "restricted";
        if (low.contains("rare") || low.matches("(?s).*\\b40\\b.*")) return "rare";
        if (low.contains("frequent") || low.matches("(?s).*\\b30\\b.*")) return "frequent";
        if (low.contains("working") || low.matches("(?s).*\\b20\\b.*")) return "working_set";
        if (low.contains("active") || low.matches("(?s).*\\b10\\b.*")) return "active";
        return "active";
    }

    private static String parseAppOp(String s) {
        if (s == null) return "allow";
        String low = s.toLowerCase(Locale.ROOT);
        if (low.contains("ignore")) return "ignore";
        if (low.contains("foreground")) return "foreground";
        if (low.contains("default")) return "default";
        if (low.contains("allow")) return "allow";
        return "allow";
    }

    private static boolean ok(String s) { return s != null && (s.contains("EXIT=0") || s.trim().isEmpty()); }

    private static void markManaged(Context c,String pkg){
        SharedPreferences p=AppPrefs.p(c); Set<String>s=new HashSet<>(p.getStringSet("managed_pkgs",new HashSet<>())); s.add(pkg); p.edit().putStringSet("managed_pkgs",s).putLong("managed_at_"+pkg,System.currentTimeMillis()).apply();
    }
    private static void unmarkManaged(Context c,String pkg){
        SharedPreferences p=AppPrefs.p(c); Set<String>s=new HashSet<>(p.getStringSet("managed_pkgs",new HashSet<>())); s.remove(pkg); p.edit().putStringSet("managed_pkgs",s).remove("managed_at_"+pkg).apply();
    }
    public static int managedCount(Context c) { return AppPrefs.p(c).getStringSet("managed_pkgs", new HashSet<>()).size(); }
    public static Set<String> managedPackages(Context c) { return new HashSet<>(AppPrefs.p(c).getStringSet("managed_pkgs", new HashSet<>())); }

    private static String appLabel(Context c,String pkg) {
        try {
            android.content.pm.PackageManager pm=c.getPackageManager();
            android.content.pm.ApplicationInfo ai=pm.getApplicationInfo(pkg,0);
            return pm.getApplicationLabel(ai).toString();
        } catch(Exception e) { return pkg; }
    }

    /**
     * Notification-critical packages must never remain in a state previously applied by Guardian
     * that can delay push delivery while the screen is off. v2.0.11 keeps notification apps
     * protected without forcing a permanent Doze whitelist, so standby battery is not distorted.
     */
    public static int restoreCriticalNotifications(Context c) {
        if (AppPrefs.restoreMode(c)) return 0;
        ShizukuBridge b = ShizukuBridge.get(c);
        if (!b.ready()) return 0;

        String[] pkgs = new String[]{
                "com.kakao.talk",
                "com.google.android.gms",
                "com.google.android.gsf"
        };
        int repaired = 0;
        for (String pkg : pkgs) {
            if (!ShizukuBridge.safePackage(pkg)) continue;
            try {
                StringBuilder raw = new StringBuilder();
                raw.append(b.exec("am set-standby-bucket --user current " + pkg + " active")).append('\n');
                raw.append(b.exec("am set-inactive --user current " + pkg + " false")).append('\n');
                raw.append(b.exec("cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND allow")).append('\n');
                raw.append(b.exec("cmd appops set " + pkg + " RUN_IN_BACKGROUND allow")).append('\n');
                raw.append(b.exec("cmd appops set " + pkg + " WAKE_LOCK allow")).append('\n');

                String bucket = parseBucket(b.exec("am get-standby-bucket " + pkg));
                String runAny = parseAppOp(b.exec("cmd appops get " + pkg + " RUN_ANY_IN_BACKGROUND"));
                String runIn = parseAppOp(b.exec("cmd appops get " + pkg + " RUN_IN_BACKGROUND"));
                String wake = parseAppOp(b.exec("cmd appops get " + pkg + " WAKE_LOCK"));
                boolean bucketOk = !"rare".equals(bucket) && !"restricted".equals(bucket);
                boolean opsOk = !"ignore".equals(runAny) && !"ignore".equals(runIn) && !"ignore".equals(wake);
                boolean success = bucketOk && opsOk;

                // Remove any Guardian bookkeeping from old versions so it cannot be re-applied/rolled back later.
                SharedPreferences p = AppPrefs.p(c);
                unmarkManaged(c, pkg);
                p.edit()
                        .remove(key("bucket",pkg))
                        .remove(key("appop",pkg))
                        .remove(key("runin",pkg))
                        .remove(key("wake",pkg))
                        .apply();

                if (success) repaired++;
                new GuardianDb(c).addAction(
                        "알림 보호 복구", pkg,
                        appLabel(c,pkg) + ": 화면 꺼짐 알림 보호 상태로 복구 · bucket=" + bucket
                                + ", RUN_ANY=" + runAny + ", RUN_IN=" + runIn + ", WAKE_LOCK=" + wake,
                        success ? "복구 확인" : "확인 필요");
            } catch (Throwable ignored) {}
        }
        if (repaired > 0) {
            AppPrefs.p(c).edit().putBoolean("critical_notification_fix_v210_done", true).apply();
            AppPrefs.setLastMessage(c, "카카오톡과 푸시 서비스의 화면 꺼짐 알림 보호 설정을 자동 복구했습니다. 앞으로 이 앱들은 백그라운드 제한 대상에서 제외합니다.");
        }
        return repaired;
    }

    public static final class RestoreSummary {
        public int total;
        public int restored;
        public int failed;
        public final java.util.List<String> details = new java.util.ArrayList<>();
        public String message() {
            StringBuilder b=new StringBuilder();
            b.append("Guardian 적용 설정 전체 원상복구 결과\n")
                    .append("복구 확인 ").append(restored).append("개 · 실패/확인 필요 ").append(failed).append("개");
            int max=Math.min(12,details.size());
            for(int i=0;i<max;i++) b.append("\n• ").append(details.get(i));
            if(details.size()>max) b.append("\n• 외 ").append(details.size()-max).append("개");
            b.append("\n\n스마트 자동 관리는 OFF 상태로 두었습니다. 학습 데이터·보호 앱·업데이트 설정은 삭제하지 않았습니다.");
            return b.toString();
        }
    }

    /**
     * Reverts settings previously changed by Guardian as far as the stored pre-change state allows.
     * It also removes the KakaoTalk Doze whitelist that v2.0.10 added, then enters diagnostic
     * restore mode so the monitor will not re-apply power-management changes during standby testing.
     */
    public static RestoreSummary restoreAllGuardianChanges(Context c) {
        RestoreSummary sum=new RestoreSummary();
        ShizukuBridge b=ShizukuBridge.get(c);
        if(!b.ready()) {
            sum.failed=1;
            sum.details.add("Shizuku 연결 필요 · 복구 명령을 실행하지 못했습니다.");
            return sum;
        }
        AppPrefs.setAutoManage(c,false);
        AppPrefs.setRestoreMode(c,true);
        SharedPreferences p=AppPrefs.p(c);
        Set<String> pkgs=new HashSet<>(p.getStringSet("managed_pkgs",new HashSet<>()));
        for(String k:p.getAll().keySet()) {
            for(String prefix:new String[]{"rb_bucket_","rb_appop_","rb_runin_","rb_wake_"}) {
                if(k.startsWith(prefix) && k.length()>prefix.length()) pkgs.add(k.substring(prefix.length()));
            }
        }
        sum.total=pkgs.size();
        for(String pkg:new HashSet<>(pkgs)) {
            boolean ok=rollback(c,pkg);
            if(ok) { sum.restored++; sum.details.add(appLabel(c,pkg)+": 원래 저장 상태로 복구 ✓"); }
            else { sum.failed++; sum.details.add(appLabel(c,pkg)+": 복구 확인 필요"); }
        }

        // v2.0.10 explicitly added this Doze whitelist. Remove the Guardian-added exception so
        // the OS can return to its normal standby policy during the diagnostic test.
        if(p.getBoolean("critical_notification_fix_v210_done",false)) {
            String r=b.exec("cmd deviceidle whitelist -com.kakao.talk");
            if(ok(r)) sum.details.add("카카오톡: Guardian이 추가한 Doze 예외 해제 ✓");
            else { sum.failed++; sum.details.add("카카오톡: Doze 예외 해제 확인 필요"); }
        }

        // v2.0.10 forced these notification-critical packages to 'allow'. Put the AppOps back to
        // system defaults, while leaving them protected from future Guardian candidate selection.
        for(String pkg:new String[]{"com.kakao.talk","com.google.android.gms","com.google.android.gsf","com.sec.spp.push"}) {
            if(!ShizukuBridge.safePackage(pkg)) continue;
            b.exec("cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND default");
            b.exec("cmd appops set " + pkg + " RUN_IN_BACKGROUND default");
            b.exec("cmd appops set " + pkg + " WAKE_LOCK default");
            b.exec("am set-inactive --user current " + pkg + " false");
        }
        p.edit().remove("critical_notification_fix_v210_done").apply();
        String msg=sum.message();
        AppPrefs.setLastMessage(c,msg);
        new GuardianDb(c).addAction("전체 원상복구","",msg,sum.failed==0?"복구 완료":"일부 확인 필요");
        return sum;
    }

    public static int restoreReusedApps(Context c){
        if(!UsageAccess.granted(c)||!ShizukuBridge.get(c).ready())return 0;
        SharedPreferences p=AppPrefs.p(c); Set<String>s=new HashSet<>(p.getStringSet("managed_pkgs",new HashSet<>())); if(s.isEmpty())return 0;
        Map<String,Long> last=UsageAccess.lastUsed(c,30L*24*3600*1000); int n=0;
        for(String pkg:new HashSet<>(s)){ long at=p.getLong("managed_at_"+pkg,0); long used=last.containsKey(pkg)?last.get(pkg):0; if(at>0&&used>at+60_000L){ if(rollback(c,pkg))n++; } }
        if(n>0) AppPrefs.setLastMessage(c,"전에 제한했던 앱을 다시 사용한 것이 확인되어 해당 앱은 자동으로 정상 상태로 돌렸습니다.");
        return n;
    }
    public static int rollbackAll(Context c){
        SharedPreferences p=AppPrefs.p(c); Set<String>s=new HashSet<>(p.getStringSet("managed_pkgs",new HashSet<>())); int n=0; for(String pkg:new HashSet<>(s))if(rollback(c,pkg))n++; return n;
    }
}
