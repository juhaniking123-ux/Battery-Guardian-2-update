package com.mec.batteryguardian2;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class CandidateFinder {
    private CandidateFinder() {}

    public static Set<String> defaultProtected(Context c) {
        Set<String> set = new HashSet<>();
        set.add(c.getPackageName());
        set.add("com.kakao.talk");
        set.add("com.google.android.gms");
        set.add("com.google.android.gsf");
        set.add("com.sec.spp.push");
        set.add("com.android.vending");
        set.add("moe.shizuku.privileged.api");
        try {
            PackageManager pm = c.getPackageManager();
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            ResolveInfo r = pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            if (r != null && r.activityInfo != null) set.add(r.activityInfo.packageName);
            String sms = android.provider.Telephony.Sms.getDefaultSmsPackage(c);
            if (sms != null) set.add(sms);
        } catch (Exception ignored) {}
        return set;
    }

    public static List<AppCandidate> find(Context c, RuleConfig rules) {
        List<AppCandidate> out = new ArrayList<>();
        if (!UsageAccess.granted(c)) return out;
        long now = System.currentTimeMillis();
        Map<String,Long> last = UsageAccess.lastUsed(c, 30L*24*3600*1000);
        Set<String> protectedSet = defaultProtected(c);
        protectedSet.addAll(AppPrefs.protectedApps(c));
        Set<String> managedSet = AppPrefs.p(c).getStringSet("managed_pkgs", new HashSet<>());
        PackageManager pm = c.getPackageManager();
        List<ApplicationInfo> apps;
        try { apps = pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0)); }
        catch (Throwable t) { apps = pm.getInstalledApplications(0); }
        for (ApplicationInfo ai : apps) {
            if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            if (protectedSet.contains(ai.packageName)) continue;
            if (managedSet.contains(ai.packageName)) continue; // 이미 제한한 앱은 반복 적용하지 않음
            if (ai.packageName.equals(c.getPackageName())) continue;
            long lu = last.containsKey(ai.packageName) ? last.get(ai.packageName) : 0L;
            long unused = lu > 0 ? now-lu : 31L*24*3600*1000;
            int level = unused >= rules.strongUnusedHours*3600_000L ? 2 : unused >= rules.moderateUnusedHours*3600_000L ? 1 : 0;
            if (level == 0) continue;
            String label;
            try { label = pm.getApplicationLabel(ai).toString(); } catch (Exception e) { label = ai.packageName; }
            out.add(new AppCandidate(ai.packageName, label, lu, unused, level));
        }
        out.sort(Comparator.comparingLong((AppCandidate a) -> a.unusedMs).reversed());
        return out;
    }

    public static List<AppCandidate> forRamBoost(Context c, RuleConfig rules) {
        List<AppCandidate> out = new ArrayList<>();
        if (!UsageAccess.granted(c)) return out;
        long now = System.currentTimeMillis();
        long min = rules.ramBoostUnusedMinutes * 60_000L;
        Map<String,Long> last = UsageAccess.lastUsed(c, 7L*24*3600*1000);
        Set<String> protectedSet = defaultProtected(c);
        protectedSet.addAll(AppPrefs.protectedApps(c));
        PackageManager pm = c.getPackageManager();
        List<ApplicationInfo> apps;
        try { apps = pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0)); }
        catch (Throwable t) { apps = pm.getInstalledApplications(0); }
        for (ApplicationInfo ai : apps) {
            if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 || protectedSet.contains(ai.packageName) || ai.packageName.equals(c.getPackageName())) continue;
            long lu = last.containsKey(ai.packageName) ? last.get(ai.packageName) : 0L;
            long unused = lu > 0 ? now-lu : 8L*24*3600*1000;
            if (unused < min) continue;
            String label; try { label = pm.getApplicationLabel(ai).toString(); } catch (Exception e) { label = ai.packageName; }
            out.add(new AppCandidate(ai.packageName,label,lu,unused,1));
        }
        out.sort(Comparator.comparingLong((AppCandidate a)->a.unusedMs).reversed());
        return out;
    }
}
