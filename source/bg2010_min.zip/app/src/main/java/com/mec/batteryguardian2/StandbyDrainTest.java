package com.mec.batteryguardian2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.PowerManager;
import java.util.Locale;

/** One-hour diagnostic test focused on screen-off standby drain. */
public final class StandbyDrainTest {
    private static final String P_PHASE="standby_test_phase"; // 0 idle, 1 running, 2 completed
    private static final String P_START="standby_test_start";
    private static final String P_START_PCT="standby_test_start_pct";
    private static final String P_START_CC="standby_test_start_cc";
    private static final String P_RESULT="standby_test_result";
    private static final String P_SCREEN_ON_MS="standby_test_screen_on_ms";
    private static final String P_LAST_STATE_AT="standby_test_last_state_at";
    private static final String P_LAST_INTERACTIVE="standby_test_last_interactive";
    private static final long TEST_MS = 60L * 60L * 1000L;

    private StandbyDrainTest() {}

    public static boolean running(Context c) { return AppPrefs.p(c).getInt(P_PHASE,0)==1; }
    public static boolean completed(Context c) { return AppPrefs.p(c).getInt(P_PHASE,0)==2; }
    public static String resultMessage(Context c) { return AppPrefs.p(c).getString(P_RESULT,""); }

    public static boolean start(Context c) {
        SystemSnapshot s=SystemSnapshot.capture(c);
        if (s.charging || s.batteryPercent < 0) return false;
        long now=System.currentTimeMillis();
        boolean interactive=isInteractive(c);
        AppPrefs.p(c).edit()
                .putInt(P_PHASE,1)
                .putLong(P_START,now)
                .putInt(P_START_PCT,s.batteryPercent)
                .putLong(P_START_CC,s.chargeCounterUah)
                .putLong(P_SCREEN_ON_MS,0L)
                .putLong(P_LAST_STATE_AT,now)
                .putBoolean(P_LAST_INTERACTIVE,interactive)
                .remove(P_RESULT)
                .apply();
        String msg="1시간 대기 배터리 테스트를 시작했습니다. 화면을 끄고 평소처럼 두세요. 충전기를 연결하면 테스트가 중단됩니다.";
        AppPrefs.setLastMessage(c,msg);
        new GuardianDb(c).addAction("대기 테스트","",msg,"진행 중");
        return true;
    }

    public static void onScreenStateChanged(Context c) { updateScreenAccounting(c); }

    public static void tick(Context c) {
        if (!running(c)) return;
        updateScreenAccounting(c);
        SharedPreferences p=AppPrefs.p(c);
        SystemSnapshot s=SystemSnapshot.capture(c);
        if (s.charging) {
            complete(c,"대기 테스트 중단: 충전이 감지되었습니다. 충전기를 분리하고 다시 시작해주세요.","중단");
            return;
        }
        long start=p.getLong(P_START,0L);
        long now=System.currentTimeMillis();
        long elapsed=Math.max(1L,now-start);
        if (elapsed < TEST_MS) return;

        int startPct=p.getInt(P_START_PCT,s.batteryPercent);
        int endPct=s.batteryPercent;
        int pctDrop=Math.max(0,startPct-endPct);
        double hours=elapsed/3600000.0;
        double pctPerHour=pctDrop/Math.max(0.01,hours);
        long startCc=p.getLong(P_START_CC,0L);
        long ccDrop=(startCc>0 && s.chargeCounterUah>0) ? Math.max(0L,startCc-s.chargeCounterUah) : 0L;
        double mahPerHour=(ccDrop/1000.0)/Math.max(0.01,hours);
        long screenOnMs=screenOnMsNow(c);
        long screenOnMin=Math.round(screenOnMs/60000.0);

        String quality = screenOnMs <= 5L*60L*1000L
                ? "화면 OFF 대기 기준으로 측정되었습니다."
                : "테스트 중 화면이 약 " + screenOnMin + "분 켜져 있어 결과는 참고용입니다.";
        StringBuilder msg=new StringBuilder();
        msg.append("1시간 대기 테스트 완료 ✓\n")
                .append("배터리 ").append(startPct).append("% → ").append(endPct).append("% · ")
                .append(pctDrop).append("% 감소\n")
                .append(String.format(Locale.KOREA,"시간당 약 %.1f%% 감소",pctPerHour));
        if (ccDrop>0) msg.append(String.format(Locale.KOREA," · 약 %.0f mAh/h",mahPerHour));
        msg.append("\n").append(quality);
        if (pctPerHour >= 2.0) msg.append("\n판정: 화면 OFF 상태에서도 소모가 큰 편이라 시스템/통신/백그라운드 원인 추가 점검이 필요합니다.");
        else if (pctPerHour <= 1.0) msg.append("\n판정: 대기 소모는 크게 비정상적인 수준으로 보이지 않습니다.");
        else msg.append("\n판정: 경계 구간입니다. 같은 조건으로 한 번 더 측정하면 판단이 더 정확합니다.");
        complete(c,msg.toString(),"완료");
    }

    public static String status(Context c) {
        SharedPreferences p=AppPrefs.p(c);
        int phase=p.getInt(P_PHASE,0);
        if (phase==0) return "대기 테스트: 미실행";
        if (phase==2) {
            String r=p.getString(P_RESULT,"테스트 완료 ✓");
            String first=r.split("\\n",2)[0];
            return "대기 테스트: " + first;
        }
        long elapsed=Math.max(0L,System.currentTimeMillis()-p.getLong(P_START,System.currentTimeMillis()));
        int min=(int)Math.min(60L,elapsed/60000L);
        int startPct=p.getInt(P_START_PCT,-1);
        return "대기 테스트: 진행 중 · 시작 " + (startPct<0?"--":startPct+"%") + " · " + min + "분 / 60분";
    }

    private static void complete(Context c,String msg,String result) {
        updateScreenAccounting(c);
        AppPrefs.p(c).edit().putInt(P_PHASE,2).putString(P_RESULT,msg).apply();
        AppPrefs.setLastMessage(c,msg);
        new GuardianDb(c).addAction("대기 테스트","",msg,result);
        try { NotificationUtil.alert(c,2311,"1시간 대기 배터리 테스트 완료",msg); } catch(Throwable ignored) {}
    }

    private static boolean isInteractive(Context c) {
        PowerManager pm=(PowerManager)c.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isInteractive();
    }

    private static void updateScreenAccounting(Context c) {
        SharedPreferences p=AppPrefs.p(c);
        if (p.getInt(P_PHASE,0)!=1) return;
        long now=System.currentTimeMillis();
        long last=p.getLong(P_LAST_STATE_AT,now);
        boolean prev=p.getBoolean(P_LAST_INTERACTIVE,isInteractive(c));
        long on=p.getLong(P_SCREEN_ON_MS,0L);
        if (prev && now>last) on += now-last;
        p.edit().putLong(P_SCREEN_ON_MS,on).putLong(P_LAST_STATE_AT,now).putBoolean(P_LAST_INTERACTIVE,isInteractive(c)).apply();
    }

    private static long screenOnMsNow(Context c) {
        updateScreenAccounting(c);
        return AppPrefs.p(c).getLong(P_SCREEN_ON_MS,0L);
    }
}
