package com.mec.batteryguardian2;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

public class MonitorService extends Service {
    private final Handler h = new Handler(Looper.getMainLooper());
    private RuleConfig rules;
    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            try {
                SystemSnapshot s = SystemSnapshot.capture(MonitorService.this);
                FullChargeTracker.observe(MonitorService.this, s);
                AnomalyDetector.observe(MonitorService.this, s);
            } catch (Throwable ignored) {}
        }
    };
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            try {
                ShizukuBridge.get(MonitorService.this).ensureBound();
                SystemSnapshot s = SystemSnapshot.capture(MonitorService.this);
                FullChargeTracker.observe(MonitorService.this, s);
                AnomalyDetector.observe(MonitorService.this, s);
                new GuardianDb(MonitorService.this).addSample(s);
                PowerActions.repairCriticalNotificationApps(MonitorService.this);
                PowerActions.restoreReusedApps(MonitorService.this);
                ExperimentController.tick(MonitorService.this);
                long now = System.currentTimeMillis();
                if (AppPrefs.autoManage(MonitorService.this) && now - AppPrefs.lastAutoScan(MonitorService.this) >= rules.autoScanMinutes*60_000L) {
                    AppPrefs.setLastAutoScan(MonitorService.this, now);
                    SmartEngine.Result r = SmartEngine.analyze(MonitorService.this, true);
                    if (r.acted) {
                        AppPrefs.setLastMessage(MonitorService.this, r.explanation);
                        NotificationUtil.alert(MonitorService.this, 2101, "배터리 자동 해결 완료", r.explanation);
                    }
                }
                String note = s.batteryPercent + "% · RAM " + s.ramUsedPercent + "% · " + ExperimentController.status(MonitorService.this);
                startForeground(2001, NotificationUtil.monitor(MonitorService.this, note));
            } catch (Throwable ignored) {}
            h.postDelayed(this, Math.max(1, rules.sampleMinutes)*60_000L);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        rules = RuleConfig.load(this);
        NotificationUtil.ensureChannels(this);
        startForeground(2001, NotificationUtil.monitor(this, "상태 확인 준비 중"));
        ShizukuBridge.get(this).ensureBound();
        IntentFilter batteryFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(batteryReceiver, batteryFilter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(batteryReceiver, batteryFilter);
        h.post(tick);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        h.removeCallbacks(tick);
        try { unregisterReceiver(batteryReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }

    public static void start(android.content.Context c) {
        Intent i = new Intent(c, MonitorService.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }
    public static void stop(android.content.Context c) { c.stopService(new Intent(c, MonitorService.class)); }
}
